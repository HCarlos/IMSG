-- MySQL dump 10.13  Distrib 5.6.38, for Linux (x86_64)
--
-- Host: localhost    Database: imsg_dbIMSG
-- ------------------------------------------------------
-- Server version	5.6.38

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary table structure for view `_viControlComentarios`
--

DROP TABLE IF EXISTS `_viControlComentarios`;
/*!50001 DROP VIEW IF EXISTS `_viControlComentarios`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `_viControlComentarios` AS SELECT 
 1 AS `idcontrolcomentario`,
 1 AS `idcontrolmaster`,
 1 AS `iduser`,
 1 AS `nombre_persona`,
 1 AS `username`,
 1 AS `comentario`,
 1 AS `fecha`,
 1 AS `idemp`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `_viControlImporte`
--

DROP TABLE IF EXISTS `_viControlImporte`;
/*!50001 DROP VIEW IF EXISTS `_viControlImporte`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `_viControlImporte` AS SELECT 
 1 AS `idimporte`,
 1 AS `idcontrolmaster`,
 1 AS `cantidad`,
 1 AS `idprecio`,
 1 AS `codigo`,
 1 AS `precio_unitario`,
 1 AS `importe`,
 1 AS `observaciones`,
 1 AS `clave_unidad`,
 1 AS `unidad_medida`,
 1 AS `clave_categoria`,
 1 AS `precio_categoria`,
 1 AS `status_importe`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `_viControlMaster`
--

DROP TABLE IF EXISTS `_viControlMaster`;
/*!50001 DROP VIEW IF EXISTS `_viControlMaster`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `_viControlMaster` AS SELECT 
 1 AS `idcontrolmaster`,
 1 AS `idempresa`,
 1 AS `idmodulo`,
 1 AS `marca`,
 1 AS `idcliente`,
 1 AS `reptte_legal`,
 1 AS `empresa`,
 1 AS `tels_contacto`,
 1 AS `cels_contacto`,
 1 AS `emails_contacto`,
 1 AS `direccion`,
 1 AS `idtecnico`,
 1 AS `tecnico`,
 1 AS `idrecibio`,
 1 AS `nombre_persona`,
 1 AS `responsable`,
 1 AS `garantia`,
 1 AS `contrato`,
 1 AS `tipo`,
 1 AS `mantto`,
 1 AS `fentrada`,
 1 AS `hora`,
 1 AS `fsalida`,
 1 AS `folgen`,
 1 AS `folmod`,
 1 AS `cargo`,
 1 AS `status`,
 1 AS `descripcion`,
 1 AS `codigo_color_hex`,
 1 AS `no_venta`,
 1 AS `no_factura`,
 1 AS `falla`,
 1 AS `accesorios`,
 1 AS `observaciones`,
 1 AS `trabajo`,
 1 AS `comment`,
 1 AS `idclienterecibioentrega`,
 1 AS `cliente_que_recibio`,
 1 AS `idtecnicoentrego`,
 1 AS `tecnico_que_entrego`,
 1 AS `status_master`,
 1 AS `idemp`,
 1 AS `creado_el`,
 1 AS `modi_el`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `_viEmpresaRepteLegal`
--

DROP TABLE IF EXISTS `_viEmpresaRepteLegal`;
/*!50001 DROP VIEW IF EXISTS `_viEmpresaRepteLegal`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `_viEmpresaRepteLegal` AS SELECT 
 1 AS `idempresarepresentantelegal`,
 1 AS `idrepresentantelegal`,
 1 AS `idempresa`,
 1 AS `reptte_legal`,
 1 AS `tels_contacto`,
 1 AS `cels_contacto`,
 1 AS `emails_contacto`,
 1 AS `direccion`,
 1 AS `empresa`,
 1 AS `emails_empresa`,
 1 AS `status_empresa_reptte_legal`,
 1 AS `idemp`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `_viEmpresaTecnico`
--

DROP TABLE IF EXISTS `_viEmpresaTecnico`;
/*!50001 DROP VIEW IF EXISTS `_viEmpresaTecnico`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `_viEmpresaTecnico` AS SELECT 
 1 AS `idempresatecnico`,
 1 AS `idtecnico`,
 1 AS `idempresa`,
 1 AS `empresa`,
 1 AS `tecnico`,
 1 AS `status_empresa_tecnico`,
 1 AS `idemp`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `_viEmpresas`
--

DROP TABLE IF EXISTS `_viEmpresas`;
/*!50001 DROP VIEW IF EXISTS `_viEmpresas`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `_viEmpresas` AS SELECT 
 1 AS `idempresa`,
 1 AS `rfc`,
 1 AS `razon_social`,
 1 AS `calle`,
 1 AS `num_ext`,
 1 AS `num_int`,
 1 AS `colonia`,
 1 AS `localidad`,
 1 AS `estado`,
 1 AS `pais`,
 1 AS `cp`,
 1 AS `emails`,
 1 AS `is_email`,
 1 AS `status_empresa`,
 1 AS `idemp`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `_viMunicipios`
--

DROP TABLE IF EXISTS `_viMunicipios`;
/*!50001 DROP VIEW IF EXISTS `_viMunicipios`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `_viMunicipios` AS SELECT 
 1 AS `idmunicipio`,
 1 AS `idestado`,
 1 AS `clave_estado`,
 1 AS `estado`,
 1 AS `clave`,
 1 AS `municipio`,
 1 AS `status_municipio`,
 1 AS `idemp`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `_viPersonas`
--

DROP TABLE IF EXISTS `_viPersonas`;
/*!50001 DROP VIEW IF EXISTS `_viPersonas`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `_viPersonas` AS SELECT 
 1 AS `idpersona`,
 1 AS `ap_paterno`,
 1 AS `ap_materno`,
 1 AS `nombre`,
 1 AS `nombre_persona`,
 1 AS `tel1`,
 1 AS `tel2`,
 1 AS `tels_contacto`,
 1 AS `cel1`,
 1 AS `cel2`,
 1 AS `cels_contacto`,
 1 AS `email1`,
 1 AS `email2`,
 1 AS `emails_contacto`,
 1 AS `curp`,
 1 AS `rfc`,
 1 AS `lugar_nacimiento`,
 1 AS `fecha_nacimiento`,
 1 AS `cfecha_nacimiento`,
 1 AS `genero`,
 1 AS `ocupacion`,
 1 AS `status_persona`,
 1 AS `domicilio_generico`,
 1 AS `calle`,
 1 AS `num_ext`,
 1 AS `num_int`,
 1 AS `colonia`,
 1 AS `localidad`,
 1 AS `estado`,
 1 AS `municipio`,
 1 AS `pais`,
 1 AS `cp`,
 1 AS `direccion`,
 1 AS `lugar_trabajo`,
 1 AS `idemp`,
 1 AS `idusuario`,
 1 AS `username`,
 1 AS `clave`,
 1 AS `idusernivelacceso`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `_viPrecios`
--

DROP TABLE IF EXISTS `_viPrecios`;
/*!50001 DROP VIEW IF EXISTS `_viPrecios`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `_viPrecios` AS SELECT 
 1 AS `idprecio`,
 1 AS `codigo`,
 1 AS `concepto`,
 1 AS `idunidadmedida`,
 1 AS `clave_unidad`,
 1 AS `unidad_medida`,
 1 AS `precio_unitario`,
 1 AS `idpreciocategoria`,
 1 AS `clave_categoria`,
 1 AS `precio_categoria`,
 1 AS `tipo`,
 1 AS `status_precio_unitario`,
 1 AS `idemp`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `_viRegFis`
--

DROP TABLE IF EXISTS `_viRegFis`;
/*!50001 DROP VIEW IF EXISTS `_viRegFis`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `_viRegFis` AS SELECT 
 1 AS `idregfis`,
 1 AS `rfc`,
 1 AS `curp`,
 1 AS `razon_social`,
 1 AS `calle`,
 1 AS `num_ext`,
 1 AS `num_int`,
 1 AS `colonia`,
 1 AS `localidad`,
 1 AS `estado`,
 1 AS `pais`,
 1 AS `cp`,
 1 AS `email1`,
 1 AS `email2`,
 1 AS `is_email`,
 1 AS `is_extranjero`,
 1 AS `referencia`,
 1 AS `idfammig`,
 1 AS `status_regfis`,
 1 AS `idemp`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `_viUsuarios`
--

DROP TABLE IF EXISTS `_viUsuarios`;
/*!50001 DROP VIEW IF EXISTS `_viUsuarios`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `_viUsuarios` AS SELECT 
 1 AS `iduser`,
 1 AS `username`,
 1 AS `password`,
 1 AS `apellidos`,
 1 AS `nombres`,
 1 AS `nombre_completo_usuario`,
 1 AS `foto`,
 1 AS `user`,
 1 AS `registro`,
 1 AS `especialidad`,
 1 AS `domicilio`,
 1 AS `colonia`,
 1 AS `idmunicipio`,
 1 AS `idestado`,
 1 AS `teloficina`,
 1 AS `telpersonal`,
 1 AS `telfax`,
 1 AS `correoelectronico`,
 1 AS `estado`,
 1 AS `municipio`,
 1 AS `idemp`,
 1 AS `empresa`,
 1 AS `logoempresa`,
 1 AS `idusernivelacceso`,
 1 AS `nivel_de_acceso`,
 1 AS `clave`,
 1 AS `status_usuario`,
 1 AS `token`,
 1 AS `token_source`,
 1 AS `token_validated`,
 1 AS `registrosporpagina`,
 1 AS `param1`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `_viUsuariosConectados`
--

DROP TABLE IF EXISTS `_viUsuariosConectados`;
/*!50001 DROP VIEW IF EXISTS `_viUsuariosConectados`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `_viUsuariosConectados` AS SELECT 
 1 AS `iduser2`,
 1 AS `isconectado`,
 1 AS `ultima_conexion`,
 1 AS `iduser`,
 1 AS `username`,
 1 AS `password`,
 1 AS `apellidos`,
 1 AS `nombres`,
 1 AS `nombre_completo_usuario`,
 1 AS `foto`,
 1 AS `user`,
 1 AS `registro`,
 1 AS `especialidad`,
 1 AS `domicilio`,
 1 AS `colonia`,
 1 AS `idmunicipio`,
 1 AS `idestado`,
 1 AS `teloficina`,
 1 AS `telpersonal`,
 1 AS `telfax`,
 1 AS `correoelectronico`,
 1 AS `estado`,
 1 AS `municipio`,
 1 AS `idemp`,
 1 AS `empresa`,
 1 AS `logoempresa`,
 1 AS `idusernivelacceso`,
 1 AS `nivel_de_acceso`,
 1 AS `clave`,
 1 AS `status_usuario`,
 1 AS `token`,
 1 AS `token_source`,
 1 AS `token_validated`,
 1 AS `registrosporpagina`,
 1 AS `param1`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `cat_colores`
--

DROP TABLE IF EXISTS `cat_colores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cat_colores` (
  `idcolor` int(5) NOT NULL AUTO_INCREMENT,
  `visualizar` tinyint(1) DEFAULT '1',
  `status` int(5) DEFAULT '0',
  `descripcion` varchar(35) DEFAULT NULL,
  `abreviatura` varchar(10) DEFAULT NULL,
  `color` varchar(35) DEFAULT NULL,
  `codigo_color_hex` varchar(25) NOT NULL,
  `status_color` tinyint(1) NOT NULL DEFAULT '1',
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL,
  `host` varchar(100) NOT NULL,
  `creado_por` int(10) NOT NULL DEFAULT '0',
  `creado_el` datetime NOT NULL,
  `modi_por` int(10) NOT NULL DEFAULT '0',
  `modi_el` datetime NOT NULL,
  PRIMARY KEY (`idcolor`),
  KEY `STATUS` (`status`),
  KEY `visualizar` (`visualizar`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_colores`
--

LOCK TABLES `cat_colores` WRITE;
/*!40000 ALTER TABLE `cat_colores` DISABLE KEYS */;
INSERT INTO `cat_colores` (`idcolor`, `visualizar`, `status`, `descripcion`, `abreviatura`, `color`, `codigo_color_hex`, `status_color`, `idemp`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`) VALUES (1,1,0,'NO INICIADO              ','NIN       ','11467210       ','#AEF9CA',1,1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(2,1,1,'EN REVISION              ','ERV       ','4194432        ','#c292f2',1,1,'187.217.204.102','customer-187-217-204-102.uninet-ide.com.mx',0,'0000-00-00 00:00:00',1,'2017-12-14 08:46:18'),(3,1,2,'EN ESPERA DE COTIZAR     ','EEC       ','65535          ','#00FFFF',1,1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(4,0,3,'COTIZADO                 ','COT       ','16776960       ','#FFFF00',1,1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(5,1,4,'EN ESPERA DE AUTORIZACION','EEA       ','EN ESPERA DE AU','#7bea0a',1,1,'189.148.243.104','dsl-189-148-243-104-dyn.prod-infinitum.com.mx',0,'0000-00-00 00:00:00',1,'2017-11-07 14:39:00'),(6,1,5,'AUTORIZADO               ','AUT       ','Autorizado','#ff80ff',1,1,'189.148.243.104','dsl-189-148-243-104-dyn.prod-infinitum.com.mx',0,'0000-00-00 00:00:00',1,'2017-11-07 14:23:32'),(7,0,6,'NO AUTORIZADO            ','NAT       ','No Autorizado','#3ecbd2',1,1,'189.148.243.104','dsl-189-148-243-104-dyn.prod-infinitum.com.mx',0,'0000-00-00 00:00:00',1,'2017-11-07 14:22:41'),(8,1,7,'EN PROCESO               ','EPR       ','En Proceso','#ff0080',1,1,'189.148.243.104','dsl-189-148-243-104-dyn.prod-infinitum.com.mx',0,'0000-00-00 00:00:00',1,'2017-11-07 14:18:02'),(9,1,8,'EN ESPERA DE REFACCION   ','EER       ','En espera de re','#d81919',1,1,'189.148.243.104','dsl-189-148-243-104-dyn.prod-infinitum.com.mx',0,'0000-00-00 00:00:00',1,'2017-11-07 14:30:50'),(10,0,9,'TERMINADO                ','TRM       ','Terminado','#ff8000',1,1,'189.148.243.104','dsl-189-148-243-104-dyn.prod-infinitum.com.mx',0,'0000-00-00 00:00:00',1,'2017-11-07 14:15:42'),(11,0,10,'CERRADO                  ','CRR       ','Cerrado','#ffff80',1,1,'189.148.243.104','dsl-189-148-243-104-dyn.prod-infinitum.com.mx',0,'0000-00-00 00:00:00',1,'2017-11-07 14:13:57');
/*!40000 ALTER TABLE `cat_colores` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`imsg`@`localhost`*/ /*!50003 TRIGGER `BEFORE_DELETE_cat_colores` BEFORE DELETE ON `cat_colores` FOR EACH ROW BEGIN

    SET @X = (
        SELECT status 
        FROM control_master 
        WHERE status = old.idcolor 
        LIMIT 1);

    IF @X > 0 THEN

        DELETE FROM `No se puede eliminar este objeto.`  
        WHERE x = -1;

    ELSE 

        SET @Y = (
            SELECT idcolor 
            FROM control_status_log 
            WHERE idcolor = old.idcolor 
            LIMIT 1);

        IF @Y > 0 THEN

            DELETE FROM `No se puede eliminar este objeto.`  
            WHERE x = -1;

        END IF;

    END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `cat_config`
--

DROP TABLE IF EXISTS `cat_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cat_config` (
  `idconfig` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `iva` decimal(5,2) NOT NULL DEFAULT '0.00',
  `intermor` decimal(5,2) NOT NULL DEFAULT '0.00',
  `interdeuda` decimal(5,2) NOT NULL DEFAULT '0.00',
  `appdescto` tinyint(1) NOT NULL DEFAULT '0',
  `faconota` tinyint(1) NOT NULL DEFAULT '0',
  `tipoventa` int(1) NOT NULL DEFAULT '0',
  `sendtoprint1` tinyint(1) NOT NULL DEFAULT '0',
  `serverpath` varchar(50) NOT NULL DEFAULT '"Server OFF"',
  `fecha_trab_trans` date NOT NULL DEFAULT '0000-00-00',
  `message` longtext NOT NULL,
  `istrans` tinyint(1) NOT NULL DEFAULT '1',
  `status_config` tinyint(1) NOT NULL DEFAULT '1',
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL,
  `host` varchar(100) NOT NULL,
  `creado_por` int(5) NOT NULL DEFAULT '0',
  `creado_el` datetime NOT NULL,
  `modi_por` int(5) NOT NULL DEFAULT '0',
  `modi_el` datetime NOT NULL,
  PRIMARY KEY (`idconfig`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Tabla de Configuraciones';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_config`
--

LOCK TABLES `cat_config` WRITE;
/*!40000 ALTER TABLE `cat_config` DISABLE KEYS */;
INSERT INTO `cat_config` (`idconfig`, `iva`, `intermor`, `interdeuda`, `appdescto`, `faconota`, `tipoventa`, `sendtoprint1`, `serverpath`, `fecha_trab_trans`, `message`, `istrans`, `status_config`, `idemp`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`) VALUES (1,15.00,0.00,0.00,1,0,0,1,'c:\\','2006-10-20','',1,1,0,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `cat_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_empresas`
--

DROP TABLE IF EXISTS `cat_empresas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cat_empresas` (
  `idempresa` int(10) NOT NULL AUTO_INCREMENT,
  `rfc` varchar(13) NOT NULL DEFAULT '',
  `razon_social` varchar(150) NOT NULL,
  `calle` varchar(100) NOT NULL,
  `num_ext` varchar(20) NOT NULL,
  `num_int` varchar(20) NOT NULL,
  `colonia` varchar(150) NOT NULL,
  `localidad` varchar(150) NOT NULL,
  `ciudad` varchar(100) NOT NULL,
  `estado` varchar(100) NOT NULL,
  `pais` varchar(100) NOT NULL,
  `cp` varchar(6) NOT NULL,
  `emails` varchar(200) NOT NULL COMMENT 'Si son varios mails, sepárelos por coma(,)',
  `is_email` tinyint(2) NOT NULL DEFAULT '1',
  `status_empresa` smallint(2) NOT NULL DEFAULT '1',
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `host` varchar(100) NOT NULL DEFAULT '',
  `creado_por` int(10) NOT NULL DEFAULT '0',
  `creado_el` datetime NOT NULL,
  `modi_por` int(10) NOT NULL DEFAULT '0',
  `modi_el` datetime NOT NULL,
  PRIMARY KEY (`idempresa`),
  UNIQUE KEY `idempresaidemp` (`rfc`,`idemp`),
  UNIQUE KEY `general_char` (`rfc`,`razon_social`,`calle`,`num_ext`,`idemp`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='Catálogo de Empresas';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_empresas`
--

LOCK TABLES `cat_empresas` WRITE;
/*!40000 ALTER TABLE `cat_empresas` DISABLE KEYS */;
INSERT INTO `cat_empresas` (`idempresa`, `rfc`, `razon_social`, `calle`, `num_ext`, `num_int`, `colonia`, `localidad`, `ciudad`, `estado`, `pais`, `cp`, `emails`, `is_email`, `status_empresa`, `idemp`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`) VALUES (1,'CAR-790922-2P','COLGIO ARJI, A.C.','AV. MEXICO','2','','DEL BOQUE','VILLAHERMOSA','','TABASCO','MéXICO','86160','janetreynes@hotmail.com',0,1,1,'187.154.150.103','dsl-187-154-150-103-dyn.prod-infinitum.com.mx',8,'2018-01-22 11:16:00',0,'0000-00-00 00:00:00'),(2,'.','FABIAN ERNESTO GOMEZ GARCIA','JUAREZ','N4','','CENTRO','JALPA DE MENDEZ','','TABASCO','MéXICO','','mosha788@hotmail.com',0,1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',8,'2018-01-22 11:18:18',0,'0000-00-00 00:00:00'),(3,'...','ALFREDO ZARRACINO MAGAÑA','AV. LA CEIBA','MANZANA 46','LOTE 4','..','....','','TABASCO','MéXICO','','alfredo.zarracino@pemex.com',0,1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',8,'2018-01-22 11:22:01',0,'0000-00-00 00:00:00'),(4,'..','JUAN CHRISTY BARRIOS','TALISMAN','208','','ATASTA','VILLAHERMOSA','','TABASCO','MéXICO','','juan1962rafael2005@outlook.com',0,1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',8,'2018-01-22 11:23:46',0,'0000-00-00 00:00:00'),(5,'ELENA','ELENA BECERRA CRUZ','ROSENDO TARACENA','136','','MAGISTERIAL','VILLAHERMOSA','','TABASCO','MéXICO','','elen_981@hotmail.com',0,1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',8,'2018-01-22 11:28:10',0,'0000-00-00 00:00:00'),(6,'LOVA','ARTURO LOPEZ VAZQUEZ','CARRETERA PRINCIPAL ','S/N','','EL CEDRO','NACAJUCA','','TABASCO','MéXICO','','alvazquez.iq@gmail.com',0,1,1,'187.154.150.103','dsl-187-154-150-103-dyn.prod-infinitum.com.mx',8,'2018-01-22 13:42:30',0,'0000-00-00 00:00:00'),(7,'PEGE','ELIAS PEREZ GOMEZ','CALLE SIN  NOMBRE','17','','CINTALAPA','NUEVA PALESTINA','','CHIAPAS','MéXICO','','eliasperezgomez@hotmail.com',0,1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',8,'2018-01-22 13:45:00',0,'0000-00-00 00:00:00'),(8,'MABY790302KK6','YVAN MARTINEZ BAEZA','ALFREDO RODRIGUEZ ROCHER','S/N.','F','QUINTIN ARAUZ','PARAISO','','TABASCO','MéXICO','','yaxuul@hotmail.com',0,1,1,'187.154.181.213','dsl-187-154-181-213-dyn.prod-infinitum.com.mx',8,'2018-01-22 13:47:00',0,'0000-00-00 00:00:00'),(9,'TMU131023PR6','TOTAL MANAGEMENT UNO  SA DE CV.','RUIZ CORTINEZ ','S/N.','F 25 F 26','ATASTA','VILLAHERMOSA','','TABASCO','MéXICO','86139','jorge.escobar@tmu.com.mx',0,1,1,'187.154.150.103','dsl-187-154-150-103-dyn.prod-infinitum.com.mx',8,'2018-01-22 13:50:47',0,'0000-00-00 00:00:00'),(10,'PME110921NK6','PETROFAC MEXICO  S.A. DE C.V.','VIA 2','108','','TABASCO 2000','VILLAHERMOSA','','TABASCO','MéXICO','86035','@',0,1,1,'187.154.181.213','dsl-187-154-181-213-dyn.prod-infinitum.com.mx',8,'2018-01-22 13:52:38',0,'0000-00-00 00:00:00'),(11,'SAT8410245V8','SEGUROS   ATLAS S.A.','AV. PASEO TABASCO','1406',' 2DO. PISO DESP.203','TABASCO 2000','VILLAHERMOSA','','TABASCO','MéXICO','86035','cobranza.tab@segurosatlas.com.m',0,1,1,'187.154.150.103','dsl-187-154-150-103-dyn.prod-infinitum.com.mx',8,'2018-01-22 13:54:48',0,'0000-00-00 00:00:00'),(12,'PNT021216TL9','PROYECTOS NACIONALES DE TRANSPORTE SA. DE CV.','BENITO JUAREZ','400','A','15 DE MAYO','ALLENDE','','NUEVO LEON','MéXICO','67350','@',0,1,1,'187.154.150.103','dsl-187-154-150-103-dyn.prod-infinitum.com.mx',8,'2018-01-22 13:58:51',0,'0000-00-00 00:00:00'),(13,'IRS120712LQ4','INTEGRADORA DE REDES Y SERVICIOS EN COMUNICACIONES SA  DE CV','MAZATEUPA','203','B','FRACC. CARRIZAL','VILLAHERMOSA','','TABASCO','MéXICO','86038','@',0,1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',8,'2018-01-22 15:18:55',0,'0000-00-00 00:00:00'),(14,'SSP090720KB3','SOLIS SASTRE PRIEGO  CONSULTORES S.C.','TELESCOPIUM','36','LOTE 30','FRACC. ESTRELLAS DE BUENA VISTA','CENTRO','','TABASCO','MéXICO','86280','solissastrepriego@gmail.com',0,1,1,'187.154.181.213','dsl-187-154-181-213-dyn.prod-infinitum.com.mx',8,'2018-01-22 15:22:22',0,'0000-00-00 00:00:00'),(15,'IAP7310271Q9','INSTITUTO DE ADMINISTRACION PUBLICA DE TABASCO A.C.','AV. LAS AMERICAS','LOCAL G3','ALTOS','ATASTA','VILLAHERMOSA','','TABASCO','MéXICO','86100','@',0,1,1,'187.154.150.103','dsl-187-154-150-103-dyn.prod-infinitum.com.mx',8,'2018-01-22 15:54:57',0,'0000-00-00 00:00:00'),(16,'AAAA000000000','CARLOS OCAÑA',',',',',',',',',',','',',','MéXICO','','',0,1,1,'187.154.214.190','dsl-187-154-214-190-dyn.prod-infinitum.com.mx',2,'2018-03-24 12:47:00',0,'0000-00-00 00:00:00'),(17,'AAAA010101000','LA ESTRELLA','BENITO','156','.','LINDA VISTA','VILLAHERMOSA, CENTRO','','TABASCO','MéXICO','86000','micorreo@mail.com',1,1,1,'187.154.205.244','dsl-187-154-205-244-dyn.prod-infinitum.com.mx',1,'2018-04-04 11:25:05',0,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `cat_empresas` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`imsg`@`localhost`*/ /*!50003 TRIGGER `BEFORE_DELETE_cat_empresas` BEFORE DELETE ON `cat_empresas` FOR EACH ROW BEGIN

    SET @X = (
        SELECT idempresa 
        FROM control_master
        WHERE idempresa = old.idempresa
        LIMIT 1);

    IF @X > 0 THEN

        DELETE FROM `No se puede eliminar esta empresa.`
        WHERE x = -1;
        
	ELSE
    
    	DELETE FROM control_master
        WHERE idempresa = old.idempresa;
    
    END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `cat_equipos_categorias`
--

DROP TABLE IF EXISTS `cat_equipos_categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cat_equipos_categorias` (
  `idequipocategoria` int(5) NOT NULL AUTO_INCREMENT,
  `equipo_categoria` varchar(50) NOT NULL,
  `status_equipo_categoria` tinyint(1) NOT NULL DEFAULT '1',
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL,
  `host` varchar(100) NOT NULL,
  `creado_por` int(5) NOT NULL DEFAULT '0',
  `creado_el` datetime NOT NULL,
  `modi_por` int(5) NOT NULL DEFAULT '0',
  `modi_el` datetime NOT NULL,
  PRIMARY KEY (`idequipocategoria`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_equipos_categorias`
--

LOCK TABLES `cat_equipos_categorias` WRITE;
/*!40000 ALTER TABLE `cat_equipos_categorias` DISABLE KEYS */;
INSERT INTO `cat_equipos_categorias` (`idequipocategoria`, `equipo_categoria`, `status_equipo_categoria`, `idemp`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`) VALUES (1,'IMPRESORA INYECCION TINTA',1,1,'187.154.208.80','dsl-187-154-208-80-dyn.prod-infinitum.com.mx',1,'2017-11-17 09:39:59',2,'2018-01-19 19:38:44'),(2,'Monitor',1,1,'187.217.204.102','customer-187-217-204-102.uninet-ide.com.mx',1,'2017-11-17 09:40:10',0,'0000-00-00 00:00:00'),(3,'Mouse Óptico',1,1,'187.217.204.102','customer-187-217-204-102.uninet-ide.com.mx',1,'2017-11-17 09:40:28',1,'2017-11-17 09:43:44'),(4,'NOBREAK',1,1,'189.148.242.111','dsl-189-148-242-111-dyn.prod-infinitum.com.mx',1,'2017-12-13 11:17:34',0,'0000-00-00 00:00:00'),(5,'TV',1,1,'187.154.208.80','dsl-187-154-208-80-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:23:57',0,'0000-00-00 00:00:00'),(6,'NOTEBOOK',1,1,'187.154.201.33','dsl-187-154-201-33-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:24:07',0,'0000-00-00 00:00:00'),(7,'BOCINA',1,1,'187.154.201.33','dsl-187-154-201-33-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:24:16',0,'0000-00-00 00:00:00'),(8,'ESTEREO',1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:24:27',0,'0000-00-00 00:00:00'),(9,'DISCO DURO INT',1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:24:43',2,'2018-01-19 19:25:26'),(10,'MEMORIA',1,1,'187.154.208.80','dsl-187-154-208-80-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:24:53',0,'0000-00-00 00:00:00'),(11,'DISCO DURO EXT',1,1,'187.154.201.33','dsl-187-154-201-33-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:25:35',0,'0000-00-00 00:00:00'),(12,'BAFLE',1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:25:54',0,'0000-00-00 00:00:00'),(13,'LAVADORA',1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:26:03',0,'0000-00-00 00:00:00'),(14,'HORNO MICROONDAS',1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:26:12',0,'0000-00-00 00:00:00'),(15,'TELEFONO',1,1,'187.154.208.80','dsl-187-154-208-80-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:26:26',0,'0000-00-00 00:00:00'),(16,'CALCULADORA',1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:26:46',0,'0000-00-00 00:00:00'),(18,'IMPRESORA LASER COLOR',1,1,'187.154.208.80','dsl-187-154-208-80-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:39:38',0,'0000-00-00 00:00:00'),(19,'IMPRESORA MATRIZ',1,1,'187.154.201.33','dsl-187-154-201-33-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:39:48',0,'0000-00-00 00:00:00'),(20,'MINIPRINTER MATRIZ',1,1,'187.154.208.80','dsl-187-154-208-80-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:40:00',0,'0000-00-00 00:00:00'),(21,'MINIPRINTER TERMICA',1,1,'187.154.208.80','dsl-187-154-208-80-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:40:11',0,'0000-00-00 00:00:00'),(22,'SECADORA',1,1,'187.154.201.33','dsl-187-154-201-33-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:40:50',0,'0000-00-00 00:00:00'),(23,'REFRIGERADOR',1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:41:03',0,'0000-00-00 00:00:00'),(24,'SWITCH',1,1,'187.154.201.33','dsl-187-154-201-33-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:41:20',2,'2018-01-19 19:42:18'),(25,'COMPUTADORA TODO EN UNO',1,1,'187.154.208.80','dsl-187-154-208-80-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:41:47',0,'0000-00-00 00:00:00'),(26,'COMPUTADORA',1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:41:56',0,'0000-00-00 00:00:00'),(27,'MULTIFUNCIONAL LASER MONO',1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:42:49',2,'2018-01-19 19:45:19'),(28,'MULTIFUNCIONAL LASER COLOR',1,1,'187.154.208.80','dsl-187-154-208-80-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:43:07',0,'0000-00-00 00:00:00'),(29,'MULTIFUNCIONAL TINTA COLOR',1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:43:51',0,'0000-00-00 00:00:00'),(30,'MULTIFUNCIONAL TINTA MONO',1,1,'187.154.208.80','dsl-187-154-208-80-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:44:04',0,'0000-00-00 00:00:00'),(31,'IMPRESORA INYECCION TINTA COLOR',1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:44:48',0,'0000-00-00 00:00:00'),(32,'IMPRESORA INYECCION TINTA MONO',1,1,'187.154.201.33','dsl-187-154-201-33-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:45:02',0,'0000-00-00 00:00:00'),(33,'CONTROL REMOTO',1,1,'187.154.205.244','dsl-187-154-205-244-dyn.prod-infinitum.com.mx',1,'2018-04-04 11:39:05',0,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `cat_equipos_categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_estados`
--

DROP TABLE IF EXISTS `cat_estados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cat_estados` (
  `idestado` int(10) NOT NULL AUTO_INCREMENT,
  `clave` varchar(10) NOT NULL,
  `estado` varchar(50) NOT NULL,
  `status_estado` int(2) NOT NULL DEFAULT '1' COMMENT '0=Inactivo, 1=Activo',
  `idemp` int(10) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `host` varchar(100) NOT NULL,
  `creado_por` int(10) NOT NULL,
  `creado_el` datetime NOT NULL,
  `modi_por` int(10) NOT NULL,
  `modi_el` datetime NOT NULL,
  PRIMARY KEY (`idestado`),
  UNIQUE KEY `cveempedo` (`clave`,`idemp`),
  KEY `idemp` (`idemp`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='Catálogo de Estados';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_estados`
--

LOCK TABLES `cat_estados` WRITE;
/*!40000 ALTER TABLE `cat_estados` DISABLE KEYS */;
INSERT INTO `cat_estados` (`idestado`, `clave`, `estado`, `status_estado`, `idemp`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`) VALUES (1,'27','TABASCO',1,1,'177.233.67.90','host-177-233-67-90.static.metrored.net.mx',0,'0000-00-00 00:00:00',3,'2014-05-23 10:30:15'),(3,'05','CHIAPAS.',1,1,'187.132.234.203','dsl-187-132-234-203-dyn.prod-infinitum.com.mx',1,'2014-08-21 15:29:12',1,'2017-08-14 19:05:33'),(4,'DF','MEXICO D.F.',1,1,'189.129.7.167','dsl-189-129-7-167-dyn.prod-infinitum.com.mx',2,'2015-02-19 08:03:57',1,'2017-06-28 12:46:24');
/*!40000 ALTER TABLE `cat_estados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_marcas`
--

DROP TABLE IF EXISTS `cat_marcas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cat_marcas` (
  `idmarca` int(10) NOT NULL AUTO_INCREMENT,
  `marca` varchar(50) NOT NULL,
  `imagen` varchar(50) NOT NULL DEFAULT '',
  `is_cat` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0=No, 1=Si',
  `status_marca` tinyint(2) NOT NULL DEFAULT '1',
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `host` varchar(100) NOT NULL DEFAULT '',
  `creado_por` int(10) NOT NULL DEFAULT '0',
  `creado_el` datetime NOT NULL,
  `modi_por` int(10) NOT NULL DEFAULT '0',
  `modi_el` datetime NOT NULL,
  PRIMARY KEY (`idmarca`),
  UNIQUE KEY `marcemp` (`marca`,`idemp`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='Catálogo de Marcas';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_marcas`
--

LOCK TABLES `cat_marcas` WRITE;
/*!40000 ALTER TABLE `cat_marcas` DISABLE KEYS */;
INSERT INTO `cat_marcas` (`idmarca`, `marca`, `imagen`, `is_cat`, `status_marca`, `idemp`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`) VALUES (4,'CANON','marca_0_1_0.png',1,1,1,'189.148.138.63','dsl-189-148-138-63-dyn.prod-infinitum.com.mx',1,'2017-11-16 13:06:14',1,'2017-12-05 13:46:27'),(5,'TOSHIBNA','marca_0_1_1.png',1,1,1,'189.129.4.155','dsl-189-129-4-155-dyn.prod-infinitum.com.mx',1,'2017-11-16 13:07:54',0,'0000-00-00 00:00:00'),(6,'TRIPP LITE','marca_0_1_2.png',1,1,1,'189.148.138.63','dsl-189-148-138-63-dyn.prod-infinitum.com.mx',1,'2017-11-16 13:11:46',1,'2017-12-05 14:03:16'),(8,'HP','marca_0_1_3.png',1,1,1,'187.154.208.80','dsl-187-154-208-80-dyn.prod-infinitum.com.mx',1,'2017-12-16 11:26:24',2,'2018-01-19 18:45:01'),(9,'PANASONIC','marca_0_1_4.png',1,1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',2,'2018-01-19 18:25:29',0,'0000-00-00 00:00:00'),(10,'EPSON','marca_0_1_5.png',1,1,1,'187.154.208.80','dsl-187-154-208-80-dyn.prod-infinitum.com.mx',2,'2018-01-19 18:36:05',0,'0000-00-00 00:00:00'),(11,'BROTHER','marca_0_1_6.png',1,1,1,'187.154.201.33','dsl-187-154-201-33-dyn.prod-infinitum.com.mx',2,'2018-01-19 18:37:04',0,'0000-00-00 00:00:00'),(12,'SAMSUNG','marca_0_1_7.png',1,1,1,'187.154.201.33','dsl-187-154-201-33-dyn.prod-infinitum.com.mx',2,'2018-01-19 18:37:57',2,'2018-01-19 18:45:37'),(13,'SONY','marca_0_1_0.jpg',1,1,1,'187.154.208.80','dsl-187-154-208-80-dyn.prod-infinitum.com.mx',2,'2018-01-19 18:38:37',2,'2018-01-19 18:42:49'),(14,'DELL','marca_0_1_8.png',1,1,1,'187.154.208.80','dsl-187-154-208-80-dyn.prod-infinitum.com.mx',2,'2018-01-19 18:39:02',2,'2018-01-19 18:43:26'),(15,'LENOVO','marca_0_1_1.jpg',1,1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',2,'2018-01-19 18:40:39',0,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `cat_marcas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_modulos`
--

DROP TABLE IF EXISTS `cat_modulos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cat_modulos` (
  `idmodulo` int(10) NOT NULL AUTO_INCREMENT,
  `categoria` varchar(15) DEFAULT NULL,
  `equipo` varchar(10) DEFAULT NULL,
  `iduser` int(10) DEFAULT NULL,
  `comment` varchar(100) DEFAULT NULL,
  `status_modulo` tinyint(1) NOT NULL DEFAULT '1',
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL,
  `host` varchar(100) NOT NULL,
  `creado_por` int(5) NOT NULL DEFAULT '0',
  `creado_el` datetime NOT NULL,
  `modi_por` int(5) NOT NULL DEFAULT '0',
  `modi_el` datetime NOT NULL,
  PRIMARY KEY (`idmodulo`),
  KEY `iduser` (`iduser`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_modulos`
--

LOCK TABLES `cat_modulos` WRITE;
/*!40000 ALTER TABLE `cat_modulos` DISABLE KEYS */;
INSERT INTO `cat_modulos` (`idmodulo`, `categoria`, `equipo`, `iduser`, `comment`, `status_modulo`, `idemp`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`) VALUES (1,'SERVICIO','GENERAL   ',15,'No se debe modificar',1,0,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(3,'SERVICIO','EPSON',4,'No se debe modificar',1,0,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(4,'GARANTIA','EPSON',4,'No se debe modificar',1,0,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(5,'SERVICIO','TOSHIBA   ',3,'No se debe modificar',1,0,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(6,'GARANTIA','TOSHIBA',3,'No se debe modificar',1,0,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(7,'SERVICIO','TRIPPLITE',14,'No se debe modificar',1,0,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(8,'GARANTIA','TRIPPLITE',14,'No se debe modificar',1,0,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(9,'SERVICIO','CANON     ',8,'No se debe modificar',1,0,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(10,'GARANTIA','CANON',4,'No se debe modificar',1,0,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(11,'SERVICIO','BENQ      ',4,'No se debe modificar',1,0,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(12,'GARANTIA','BENQ',4,'No se debe modificar',1,0,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(2,'GARANTIA','GENERAL   ',15,'No se debe modificar',1,0,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(13,'SERVICIO','HP',15,'No se debe modificar',1,0,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(14,'GARANTIA','HP',15,'No se debe modificar',1,0,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(15,'SERVICIO','SAMSUNG',15,'No se debe modificar',1,0,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(16,'GARANTIA','SAMSUNG',15,'No se debe modificar',1,0,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(17,'SERVICIO','BROTHER',15,'No se debe modificar',1,0,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(18,'GARANTIA','BROTHTER',15,'No se debe modificar',1,0,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `cat_modulos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_municipios`
--

DROP TABLE IF EXISTS `cat_municipios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cat_municipios` (
  `idmunicipio` int(10) NOT NULL AUTO_INCREMENT,
  `idestado` varchar(10) NOT NULL,
  `clave` varchar(10) NOT NULL,
  `municipio` varchar(100) NOT NULL,
  `status_municipio` int(2) NOT NULL DEFAULT '1' COMMENT '0=Inactivo, 1=Activo',
  `idemp` int(5) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `host` varchar(100) NOT NULL,
  `creado_por` int(10) NOT NULL,
  `creado_el` datetime NOT NULL,
  `modi_por` int(10) NOT NULL,
  `modi_el` datetime NOT NULL,
  PRIMARY KEY (`idmunicipio`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COMMENT='Catálogo de Municipios';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_municipios`
--

LOCK TABLES `cat_municipios` WRITE;
/*!40000 ALTER TABLE `cat_municipios` DISABLE KEYS */;
INSERT INTO `cat_municipios` (`idmunicipio`, `idestado`, `clave`, `municipio`, `status_municipio`, `idemp`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`) VALUES (1,'1','001','Balancán',0,1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(2,'1','002','Cárdenas',0,1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(3,'1','003','Centla',0,1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(4,'1','04','CENTRO',1,1,'189.133.155.62','dsl-189-133-155-62-dyn.prod-infinitum.com.mx',0,'0000-00-00 00:00:00',3,'2014-07-17 12:54:16'),(5,'1','005','Comalcalco',0,1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(6,'1','006','Cunduacán',0,1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(7,'1','007','Emiliano Zapata',0,1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(8,'1','008','Huimanguillo',0,1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(9,'1','009','Jalapa',0,1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(10,'1','010','Jalpa de Méndez',0,1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(11,'1','011','Jonuta',0,1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(12,'1','012','Macuspana',0,1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(13,'1','013','Nacajuca',0,1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(14,'1','014','Paraiso',0,1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(15,'1','015','Tacotalp',0,1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(16,'1','016','Teapa',0,1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(17,'1','017','Tenosique',0,1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(19,'1','01','BALANCAN',0,1,'189.133.196.4','dsl-189-133-196-4-dyn.prod-infinitum.com.mx',3,'2014-05-07 14:03:47',1,'2014-05-09 18:36:38'),(20,'1','02','CARDENAS',0,1,'189.133.196.4','dsl-189-133-196-4-dyn.prod-infinitum.com.mx',3,'2014-05-07 14:04:20',1,'2014-05-09 18:36:49'),(21,'1','01','BALANCAN',1,1,'189.133.155.62','dsl-189-133-155-62-dyn.prod-infinitum.com.mx',3,'2014-07-16 17:48:44',3,'2014-07-17 12:53:00'),(22,'1','02','CARDENAS',1,1,'189.133.155.62','dsl-189-133-155-62-dyn.prod-infinitum.com.mx',3,'2014-07-17 12:53:31',0,'0000-00-00 00:00:00'),(23,'1','03','CENTLA',1,1,'189.133.183.246','dsl-189-133-183-246-dyn.prod-infinitum.com.mx',3,'2014-07-17 12:53:52',0,'0000-00-00 00:00:00'),(24,'1','05','COMALCALCO',1,1,'189.133.155.62','dsl-189-133-155-62-dyn.prod-infinitum.com.mx',3,'2014-07-17 12:54:30',0,'0000-00-00 00:00:00'),(25,'1','06','CUNDUACAN',1,1,'189.133.183.246','dsl-189-133-183-246-dyn.prod-infinitum.com.mx',3,'2014-07-17 12:54:58',0,'0000-00-00 00:00:00'),(26,'1','07','EMILIANO ZAPATA',1,1,'189.133.183.246','dsl-189-133-183-246-dyn.prod-infinitum.com.mx',3,'2014-07-17 12:55:14',0,'0000-00-00 00:00:00'),(27,'1','08','HUIMANGUILLO',1,1,'189.133.183.246','dsl-189-133-183-246-dyn.prod-infinitum.com.mx',3,'2014-07-17 12:55:28',0,'0000-00-00 00:00:00'),(28,'1','09','JALAPA',1,1,'189.133.183.246','dsl-189-133-183-246-dyn.prod-infinitum.com.mx',3,'2014-07-17 12:56:00',0,'0000-00-00 00:00:00'),(29,'1','10','JALPA DE MENDEZ',1,1,'189.133.183.246','dsl-189-133-183-246-dyn.prod-infinitum.com.mx',3,'2014-07-17 12:56:11',0,'0000-00-00 00:00:00'),(30,'1','11','JONUTA',1,1,'189.133.183.246','dsl-189-133-183-246-dyn.prod-infinitum.com.mx',3,'2014-07-17 12:56:21',0,'0000-00-00 00:00:00'),(31,'1','12','MACUSPANA',1,1,'189.133.125.117','dsl-189-133-125-117-dyn.prod-infinitum.com.mx',3,'2014-07-17 12:56:32',63,'2014-08-05 15:25:57'),(32,'1','11','NACAJUCA',1,1,'189.133.183.246','dsl-189-133-183-246-dyn.prod-infinitum.com.mx',3,'2014-07-17 12:56:49',0,'0000-00-00 00:00:00'),(33,'1','12','PARAISO',1,1,'189.133.155.62','dsl-189-133-155-62-dyn.prod-infinitum.com.mx',3,'2014-07-17 12:57:00',0,'0000-00-00 00:00:00'),(34,'1','15','TACOTALPA',1,1,'189.133.155.62','dsl-189-133-155-62-dyn.prod-infinitum.com.mx',3,'2014-07-17 12:57:38',0,'0000-00-00 00:00:00'),(35,'1','16','TEAPA',1,1,'189.133.155.62','dsl-189-133-155-62-dyn.prod-infinitum.com.mx',3,'2014-07-17 12:57:49',0,'0000-00-00 00:00:00'),(36,'1','17','TENOSIQUE',1,1,'189.133.155.62','dsl-189-133-155-62-dyn.prod-infinitum.com.mx',3,'2014-07-17 12:57:58',0,'0000-00-00 00:00:00'),(37,'3','RFM','REFORMA',1,1,'189.133.203.0','189.133.203.0',1,'2014-08-21 15:34:08',1,'2014-08-21 15:34:19'),(38,'1','001','CARDENAS',1,1,'187.217.204.107','customer-187-217-204-107.uninet-ide.com.mx',66,'2014-09-26 07:54:27',0,'0000-00-00 00:00:00'),(39,'4','DF','MEXICO D.F.',1,1,'189.133.206.66','dsl-189-133-206-66-dyn.prod-infinitum.com.mx',2,'2015-02-19 08:04:34',1,'2015-02-19 08:06:37');
/*!40000 ALTER TABLE `cat_municipios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_personas`
--

DROP TABLE IF EXISTS `cat_personas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cat_personas` (
  `idpersona` int(10) NOT NULL AUTO_INCREMENT,
  `idusuario` int(10) DEFAULT '0',
  `curp` varchar(18) NOT NULL,
  `rfc` varchar(15) NOT NULL,
  `ap_paterno` varchar(50) NOT NULL,
  `ap_materno` varchar(50) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `tel1` varchar(100) NOT NULL,
  `tel2` varchar(100) NOT NULL,
  `cel1` varchar(100) NOT NULL,
  `cel2` varchar(100) NOT NULL,
  `email1` varchar(250) NOT NULL,
  `email2` varchar(250) NOT NULL,
  `lugar_nacimiento` varchar(100) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `genero` int(2) NOT NULL DEFAULT '0' COMMENT '0=Mujer, 1=Hombre',
  `profesion` varchar(150) NOT NULL,
  `ocupacion` varchar(100) NOT NULL,
  `domicilio_generico` text NOT NULL,
  `calle` varchar(100) NOT NULL,
  `num_ext` varchar(20) NOT NULL,
  `num_int` varchar(20) NOT NULL,
  `colonia` varchar(100) NOT NULL,
  `localidad` varchar(100) NOT NULL,
  `municipio` varchar(50) NOT NULL,
  `estado` varchar(20) NOT NULL,
  `pais` varchar(20) NOT NULL,
  `cp` varchar(6) NOT NULL,
  `lugar_trabajo` varchar(250) NOT NULL,
  `iddomicilio` int(10) NOT NULL DEFAULT '0',
  `idpermig` int(10) NOT NULL,
  `empresa` varchar(250) NOT NULL,
  `status_persona` int(2) NOT NULL DEFAULT '1',
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL,
  `host` varchar(100) NOT NULL,
  `creado_por` int(5) NOT NULL,
  `creado_el` datetime NOT NULL,
  `modi_por` int(5) NOT NULL,
  `modi_el` datetime NOT NULL,
  PRIMARY KEY (`idpersona`),
  UNIQUE KEY `appapmnomemp` (`ap_paterno`,`ap_materno`,`nombre`,`idemp`) USING BTREE,
  KEY `idemp` (`idemp`),
  KEY `status_persona` (`status_persona`),
  KEY `geemp` (`genero`,`idemp`),
  KEY `idpermig` (`idpermig`),
  KEY `useremp` (`idusuario`,`idemp`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COMMENT='Catálogo de Personas';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_personas`
--

LOCK TABLES `cat_personas` WRITE;
/*!40000 ALTER TABLE `cat_personas` DISABLE KEYS */;
INSERT INTO `cat_personas` (`idpersona`, `idusuario`, `curp`, `rfc`, `ap_paterno`, `ap_materno`, `nombre`, `tel1`, `tel2`, `cel1`, `cel2`, `email1`, `email2`, `lugar_nacimiento`, `fecha_nacimiento`, `genero`, `profesion`, `ocupacion`, `domicilio_generico`, `calle`, `num_ext`, `num_int`, `colonia`, `localidad`, `municipio`, `estado`, `pais`, `cp`, `lugar_trabajo`, `iddomicilio`, `idpermig`, `empresa`, `status_persona`, `idemp`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`) VALUES (1,11,'','','AGUILAR','MONTESINOS','RUBEN ARTURO','9933126004 ext. 120','9933129713 ext. 120','','','ruben.aguilar@imsdelgolfo.com.mx','','VILLAERMOSA, TABASCO','2018-01-19',1,'','LIC. EN INFORMATICA','','LOPEZ MATEOS','120','','CENTRO','VILLAHERMOSA','CENTRO','TABASCO','MÉXICO','86130','IMSG',0,0,'',1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',2,'2018-01-19 18:56:29',0,'0000-00-00 00:00:00'),(3,9,'','','REVUELTAS','RODRIGUEZ','JOSE','9933126004 EXT. 102','','','','','','VILLAERMOSA, TABASCO','1969-09-25',1,'','ING. ELECTRONICA','','AV GREGORIO MENDEZ','1500','B','LIDIA ESTHER','VILLAHERMOSA','CENTRO','TABASCO','MÉXICO','86040','IMSG',0,0,'',1,1,'187.154.201.33','dsl-187-154-201-33-dyn.prod-infinitum.com.mx',2,'2018-01-19 18:58:37',2,'2018-01-19 19:08:21'),(5,18,'','','GARCIA','ARIAS','NATIVIDAD','9933126004 ext. 107','9933129713 ext. 107','','','nato.garcia@imsdelgolfo.com.mx','','VILLAERMOSA, TABASCO','2018-01-19',1,'','ASISTENTE FACTURACION','','CONCIDO','150','','CENTRO','VILLAHERMOSA','CENTRO','TABASCO','MÉXICO','86000','IMSG',0,0,'',1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:06:40',0,'0000-00-00 00:00:00'),(6,17,'','','VILLARREAL','DE LA FLOR','ALICIA','9933126004 ext. 101','9933129713 ext. 101','','','alicia.villarreal@imsdelgolfo.com.mx','','VILLAERMOSA, TABASCO','2018-01-19',0,'','RECEPCION','','CONCIDO','120','','CONCIDO','VILLAHERMOSA','CENTRO','TABASCO','MÉXICO','86000','IMSG',0,0,'',1,1,'187.154.208.80','dsl-187-154-208-80-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:10:19',0,'0000-00-00 00:00:00'),(8,16,'','','SILVA','LOPEZ','EFREN','9933126004 ext. 108','9933129713 ext. 108','','','efren.silva@imsdelgolfo.com.mx','','VILLAERMOSA, TABASCO','2018-01-19',1,'','TECNICO ELECTRONICA','','CONCIDO','100','','CENTRO','VILLAHERMOSA','CENTRO','TABASCO','MÉXICO','86000','IMSG',0,0,'',1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:14:53',0,'0000-00-00 00:00:00'),(9,13,'','','BEAURREGARD','OLAN ','LORENA','9933126004 ext. 106','9933129713 ext. 106','','','lorenab@imsdelgolfo.com.mx','','VILLAERMOSA, TABASCO','2018-01-19',0,'','LIC. EN INFORMATICA','','CONCIDO','444','','CENTRO','VILLAHERMOSA','CENTRO','TABASCO','MÉXICO','86000','IMSG',0,0,'',1,1,'187.154.201.33','dsl-187-154-201-33-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:17:18',0,'0000-00-00 00:00:00'),(11,15,'','','ULIN','SASTRE','REMIGIO','9933126004 ext. 118','9933129713 ext. 118','','','rulin@imsdelgolfo.com.mx','','VILLAERMOSA, TABASCO','2018-01-19',1,'','TECNICO ELECTRONICA','','CONCIDO','120','','CENTRO','VILLAHERMOSA','CENTRO','TABASCO','MÉXICO','86000','IMSG',0,0,'',1,1,'187.154.201.33','dsl-187-154-201-33-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:20:48',0,'0000-00-00 00:00:00'),(14,14,'','','OCAÑA','','CARLOS ','','','','','','','','2018-03-23',0,'','','','','','','','','CENTRO','TABASCO','MÉXICO','','',0,0,'',1,1,'189.148.186.136','dsl-189-148-186-136-dyn.prod-infinitum.com.mx',2,'2018-03-23 19:05:15',0,'0000-00-00 00:00:00'),(15,20,'','','SANTARELLI','','CARLOS','','','','','','','','2018-03-23',0,'','','','','','','','','CENTRO','TABASCO','MÉXICO','','',0,0,'',1,1,'189.148.186.136','dsl-189-148-186-136-dyn.prod-infinitum.com.mx',2,'2018-03-23 19:05:27',0,'0000-00-00 00:00:00'),(18,12,'','','DIAZ','LOPEZ','CLAUDIO','','','','','','','','2018-03-24',1,'','','','','','','','','CENTRO','TABASCO','MÉXICO','','',0,0,'',1,1,'187.154.214.190','dsl-187-154-214-190-dyn.prod-infinitum.com.mx',2,'2018-03-24 11:14:33',0,'0000-00-00 00:00:00'),(21,19,'','','prueba','prueba','prueba','','','111','111','user@example.com','user@example.com','','2018-04-06',0,'','','','','','','','','CENTRO','TABASCO','MÉXICO','','',0,0,'',1,1,'189.148.158.183','dsl-189-148-158-183-dyn.prod-infinitum.com.mx',2,'2018-04-06 13:35:46',2,'2018-04-06 18:55:42');
/*!40000 ALTER TABLE `cat_personas` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`imsg`@`localhost`*/ /*!50003 TRIGGER `BEFORE_INSERT_cat_personas` BEFORE INSERT ON `cat_personas` FOR EACH ROW BEGIN

set @x = (SELECT idpersona 
          FROM _viPersonas 
          WHERE nombre_persona = CONCAT(
              UCASE(TRIM(new.ap_paterno)), ' ',
              UCASE(TRIM(new.ap_materno)), ' ',
              UCASE(TRIM(new.nombre)) 
          ) 
         );

if @x > 0 THEN
   Delete from `Persona repetida.` where x = -1;
end if;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`imsg`@`localhost`*/ /*!50003 TRIGGER `BEFORE_UPDATE_cat_personas` BEFORE UPDATE ON `cat_personas` FOR EACH ROW BEGIN

set @x = (SELECT COUNT(idpersona) as numPer  
          FROM _viPersonas 
          WHERE nombre_persona = CONCAT(
              UCASE(TRIM(new.ap_paterno)), ' ',
              UCASE(TRIM(new.ap_materno)), ' ',
              UCASE(TRIM(new.nombre)) 
          ) 
         );

if @x > 1 THEN
   Delete from `Persona repetida.` where x = -1;
end if;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`imsg`@`localhost`*/ /*!50003 TRIGGER `BEFORE_DELETE_cat_personas` BEFORE DELETE ON `cat_personas` FOR EACH ROW BEGIN

    SET @x = (SELECT iduser FROM usuarios WHERE iduser = old.idusuario);

    IF @x > 0 THEN

	    Delete 
        from `No se puede eliminar este Usuario.` 
        where x = -1;

	ELSE
    
    	SET @y = (
            SELECT idrepresentantelegal 
            FROM empresas_reptte_legal 
            WHERE idrepresentantelegal = old.idpersona
        );
        IF @y > 0 THEN
        
            Delete 
            from `No se puede eliminar este Contacto.` 
            where x = -1;
            
        ELSE
        

            SET @z = (
                SELECT idtecnico 
                FROM empresas_tecnicos 
                WHERE idtecnico = old.idpersona
            );
            IF @z > 0 THEN

                Delete 
                from `No se puede eliminar este Técnico.` 
                where x = -1;

            END IF;
        
        
    	END IF;

    END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `cat_precios`
--

DROP TABLE IF EXISTS `cat_precios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cat_precios` (
  `idprecio` int(10) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(25) NOT NULL DEFAULT '',
  `concepto` varchar(250) NOT NULL DEFAULT '',
  `idunidadmedida` int(5) NOT NULL DEFAULT '0',
  `precio_unitario` decimal(10,2) NOT NULL DEFAULT '0.00',
  `idpreciocategoria` int(5) NOT NULL DEFAULT '0',
  `tipo` varchar(150) NOT NULL DEFAULT '',
  `status_precio_unitario` tinyint(1) NOT NULL DEFAULT '1',
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `host` varchar(100) NOT NULL DEFAULT '',
  `creado_por` int(5) NOT NULL DEFAULT '0',
  `creado_el` datetime NOT NULL,
  `modi_por` int(5) NOT NULL DEFAULT '0',
  `modi_el` datetime NOT NULL,
  PRIMARY KEY (`idprecio`),
  UNIQUE KEY `codigo` (`codigo`) USING BTREE,
  KEY `idmedida` (`idunidadmedida`),
  KEY `idpreciocategoria` (`idpreciocategoria`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='Guarda los precios de los códigos';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_precios`
--

LOCK TABLES `cat_precios` WRITE;
/*!40000 ALTER TABLE `cat_precios` DISABLE KEYS */;
INSERT INTO `cat_precios` (`idprecio`, `codigo`, `concepto`, `idunidadmedida`, `precio_unitario`, `idpreciocategoria`, `tipo`, `status_precio_unitario`, `idemp`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`) VALUES (1,'servac1','de 1 a 5 tons',1,580.00,1,'interno',1,1,'189.129.19.124','dsl-189-129-19-124-dyn.prod-infinitum.com.mx',1,'2017-12-19 15:40:50',1,'2017-12-19 15:46:39'),(3,'yhghhn','sdfasdf',1,344.00,2,'sdfasd',1,1,'187.217.204.102','customer-187-217-204-102.uninet-ide.com.mx',1,'2017-12-20 08:31:29',0,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `cat_precios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_precios_categorias`
--

DROP TABLE IF EXISTS `cat_precios_categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cat_precios_categorias` (
  `idpreciocategoria` int(5) NOT NULL AUTO_INCREMENT,
  `clave` varchar(25) NOT NULL DEFAULT '',
  `precio_categoria` varchar(100) NOT NULL DEFAULT '',
  `status_precio_categoria` tinyint(1) NOT NULL DEFAULT '1',
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `host` varchar(100) NOT NULL DEFAULT '',
  `creado_por` int(5) NOT NULL DEFAULT '0',
  `creado_el` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modi_por` int(5) NOT NULL DEFAULT '0',
  `modi_el` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idpreciocategoria`),
  UNIQUE KEY `cveprec` (`clave`,`precio_categoria`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='Catálogo de Categorías de Precios';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_precios_categorias`
--

LOCK TABLES `cat_precios_categorias` WRITE;
/*!40000 ALTER TABLE `cat_precios_categorias` DISABLE KEYS */;
INSERT INTO `cat_precios_categorias` (`idpreciocategoria`, `clave`, `precio_categoria`, `status_precio_categoria`, `idemp`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`) VALUES (1,'SERVAC1','CONV LG1',1,1,'189.129.19.124','dsl-189-129-19-124-dyn.prod-infinitum.com.mx',1,'2017-12-19 14:34:06',1,'2017-12-19 14:45:04'),(2,'SERVAC1','INVERTER LG1',1,1,'189.129.19.124','dsl-189-129-19-124-dyn.prod-infinitum.com.mx',1,'2017-12-19 14:35:50',0,'2017-12-19 14:35:50'),(4,'REVISION1','REVISION Y DIAGNOSTICO',1,1,'187.154.201.33','dsl-187-154-201-33-dyn.prod-infinitum.com.mx',2,'2018-01-19 19:29:05',0,'2018-01-19 19:29:05');
/*!40000 ALTER TABLE `cat_precios_categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_registros_fiscales`
--

DROP TABLE IF EXISTS `cat_registros_fiscales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cat_registros_fiscales` (
  `idregfis` int(10) NOT NULL AUTO_INCREMENT,
  `rfc` varchar(20) NOT NULL,
  `curp` varchar(18) NOT NULL,
  `razon_social` varchar(200) NOT NULL,
  `calle` varchar(100) NOT NULL,
  `num_ext` varchar(20) NOT NULL,
  `num_int` varchar(20) NOT NULL,
  `colonia` varchar(150) NOT NULL,
  `localidad` varchar(100) NOT NULL,
  `estado` varchar(50) NOT NULL,
  `pais` varchar(10) NOT NULL DEFAULT '"MÉXICO"',
  `cp` varchar(10) NOT NULL,
  `email1` varchar(100) NOT NULL,
  `email2` varchar(100) NOT NULL,
  `is_email` int(2) NOT NULL DEFAULT '1',
  `is_extranjero` int(2) NOT NULL DEFAULT '0',
  `referencia` varchar(100) NOT NULL,
  `idfammig` int(10) NOT NULL DEFAULT '0',
  `valid_for_admin` int(2) NOT NULL DEFAULT '1' COMMENT '0=No, 1=Si',
  `status_regfis` int(2) NOT NULL DEFAULT '1' COMMENT '0=Inactivo, 1=Activo',
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL,
  `host` varchar(100) NOT NULL,
  `creado_por` int(5) NOT NULL,
  `creado_el` datetime NOT NULL,
  `modi_por` int(5) NOT NULL,
  `modi_el` datetime NOT NULL,
  PRIMARY KEY (`idregfis`),
  UNIQUE KEY `rfcemp` (`rfc`,`idemp`),
  KEY `rfc` (`rfc`),
  KEY `curp` (`curp`),
  KEY `is_email` (`is_email`),
  KEY `is_extrajero` (`is_extranjero`),
  KEY `status_regfis` (`status_regfis`),
  KEY `idemp` (`idemp`),
  KEY `statusemp` (`idemp`,`status_regfis`),
  KEY `curpemp` (`curp`,`idemp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Guarda los registros fiscales';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_registros_fiscales`
--

LOCK TABLES `cat_registros_fiscales` WRITE;
/*!40000 ALTER TABLE `cat_registros_fiscales` DISABLE KEYS */;
/*!40000 ALTER TABLE `cat_registros_fiscales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cat_unidades_medidas`
--

DROP TABLE IF EXISTS `cat_unidades_medidas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cat_unidades_medidas` (
  `idunidadmedida` int(5) NOT NULL AUTO_INCREMENT,
  `clave` varchar(25) NOT NULL DEFAULT '',
  `unidad_medida` varchar(100) NOT NULL DEFAULT '',
  `status_unidad_medida` tinyint(1) NOT NULL DEFAULT '1',
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `host` varchar(100) NOT NULL DEFAULT '',
  `creado_por` int(5) NOT NULL DEFAULT '0',
  `creado_el` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modi_por` int(5) NOT NULL DEFAULT '0',
  `modi_el` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idunidadmedida`),
  UNIQUE KEY `cveunimed` (`clave`,`unidad_medida`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='Catálogo de Unidades de Medida';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cat_unidades_medidas`
--

LOCK TABLES `cat_unidades_medidas` WRITE;
/*!40000 ALTER TABLE `cat_unidades_medidas` DISABLE KEYS */;
INSERT INTO `cat_unidades_medidas` (`idunidadmedida`, `clave`, `unidad_medida`, `status_unidad_medida`, `idemp`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`) VALUES (1,'MINISPLIT','CLIMA MINISPLIT',1,1,'189.129.19.124','dsl-189-129-19-124-dyn.prod-infinitum.com.mx',1,'2017-12-19 14:56:33',0,'2017-12-19 14:58:20'),(2,'VENTANA','CLIMA DE VENTANA',1,1,'189.129.19.124','dsl-189-129-19-124-dyn.prod-infinitum.com.mx',1,'2017-12-19 14:56:48',0,'2017-12-19 14:58:20'),(3,'PZA','PIEZA',1,1,'189.129.19.124','dsl-189-129-19-124-dyn.prod-infinitum.com.mx',1,'2017-12-19 14:57:04',1,'2017-12-19 14:58:33'),(5,'SERV','SERVICIO',1,1,'187.154.195.202','dsl-187-154-195-202-dyn.prod-infinitum.com.mx',8,'2018-01-19 17:50:57',8,'2018-01-19 17:53:41');
/*!40000 ALTER TABLE `cat_unidades_medidas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `idconfig` int(11) NOT NULL AUTO_INCREMENT,
  `llave` varchar(100) NOT NULL,
  `valor` varchar(100) NOT NULL,
  `observaciones` varchar(150) NOT NULL,
  `idemp` int(5) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `host` varchar(100) NOT NULL,
  `creado_por` int(5) NOT NULL DEFAULT '0',
  `creado_el` datetime NOT NULL,
  `modi_por` int(5) NOT NULL DEFAULT '0',
  `modi_el` datetime NOT NULL,
  PRIMARY KEY (`idconfig`),
  UNIQUE KEY `keyempcnf` (`llave`,`idemp`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='Configuraciones';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` (`idconfig`, `llave`, `valor`, `observaciones`, `idemp`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`) VALUES (1,'iva','0.16','',1,'','0',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(2,'logo-emp-rep','logo-imsg.gif','Se utiliza para diversos formatos. El nombre \'logo-emp-rep\' no se debe cambiar',1,'','0',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`imsg`@`localhost`*/ /*!50003 TRIGGER `BEFORE_UPDATE_config` BEFORE UPDATE ON `config` FOR EACH ROW Begin

INSERT INTO logs(iduser,date_mov,typemov,table_mov,idkey,fieldkey)
VALUES(new.modi_por,NOW(),'Update','Config',new.valor,new.llave);


End */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `control_comentarios`
--

DROP TABLE IF EXISTS `control_comentarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `control_comentarios` (
  `idcontrolcomentario` int(10) NOT NULL AUTO_INCREMENT,
  `idcontrolmaster` int(10) NOT NULL DEFAULT '0',
  `iduser` int(10) NOT NULL DEFAULT '0',
  `comentario` varchar(250) NOT NULL DEFAULT '',
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL,
  `host` varchar(100) NOT NULL,
  `creado_por` int(5) NOT NULL DEFAULT '0',
  `creado_el` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modi_por` int(5) NOT NULL DEFAULT '0',
  `modi_el` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idcontrolcomentario`),
  KEY `idcontrolmaster` (`idcontrolmaster`,`idemp`) USING BTREE,
  KEY `iduser` (`iduser`,`idemp`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='Guarda los comentarios de la Tabla';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `control_comentarios`
--

LOCK TABLES `control_comentarios` WRITE;
/*!40000 ALTER TABLE `control_comentarios` DISABLE KEYS */;
INSERT INTO `control_comentarios` (`idcontrolcomentario`, `idcontrolmaster`, `iduser`, `comentario`, `fecha`, `idemp`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`) VALUES (1,1,9,'El equipo ya se cotizó','2018-03-24 11:51:30',1,'187.154.214.190','dsl-187-154-214-190-dyn.prod-infinitum.com.mx',2,'2018-03-24 11:51:30',0,'2018-03-24 11:51:30'),(2,1,9,'El cliente vino y se puso enojado...','2018-03-24 11:53:09',1,'187.154.214.190','dsl-187-154-214-190-dyn.prod-infinitum.com.mx',2,'2018-03-24 11:53:09',0,'2018-03-24 11:53:09'),(3,2,14,'Se encotró una salamandra en el TV','2018-04-04 11:47:43',1,'187.154.205.244','dsl-187-154-205-244-dyn.prod-infinitum.com.mx',1,'2018-04-04 11:47:43',0,'2018-04-04 11:47:43'),(4,2,14,'Se contacto al cliente via telefónica y contestó su hijo.','2018-04-04 11:50:56',1,'187.154.205.244','dsl-187-154-205-244-dyn.prod-infinitum.com.mx',1,'2018-04-04 11:50:56',0,'2018-04-04 11:50:56'),(5,2,14,'hablo cleinte que ecesita secomuniquen','2018-04-06 09:07:54',1,'187.154.205.244','dsl-187-154-205-244-dyn.prod-infinitum.com.mx',2,'2018-04-06 09:07:54',0,'2018-04-06 09:07:54');
/*!40000 ALTER TABLE `control_comentarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `control_detalle`
--

DROP TABLE IF EXISTS `control_detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `control_detalle` (
  `iddetalle` int(10) NOT NULL AUTO_INCREMENT,
  `idcontrolmaster` int(10) DEFAULT '0',
  `idequipocategoria` int(5) NOT NULL DEFAULT '0',
  `equipo` varchar(50) DEFAULT '',
  `idmarca` int(5) NOT NULL DEFAULT '0',
  `marca` varchar(50) DEFAULT '',
  `modelo` varchar(50) DEFAULT '',
  `serie` varchar(50) DEFAULT '',
  `no_parte` varchar(50) DEFAULT '',
  `version` varchar(50) NOT NULL DEFAULT '',
  `submodelo` varchar(50) NOT NULL DEFAULT '',
  `num_pedido` varchar(50) NOT NULL DEFAULT '',
  `contar` int(2) DEFAULT '0',
  `status_detalle` tinyint(1) NOT NULL DEFAULT '1',
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `host` varchar(100) NOT NULL DEFAULT '',
  `creado_por` int(10) DEFAULT '0',
  `creado_el` datetime DEFAULT CURRENT_TIMESTAMP,
  `modi_por` int(10) DEFAULT '0',
  `modi_el` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`iddetalle`),
  KEY `idcontrol` (`idcontrolmaster`),
  KEY `modelo` (`modelo`),
  KEY `serie` (`serie`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `control_detalle`
--

LOCK TABLES `control_detalle` WRITE;
/*!40000 ALTER TABLE `control_detalle` DISABLE KEYS */;
INSERT INTO `control_detalle` (`iddetalle`, `idcontrolmaster`, `idequipocategoria`, `equipo`, `idmarca`, `marca`, `modelo`, `serie`, `no_parte`, `version`, `submodelo`, `num_pedido`, `contar`, `status_detalle`, `idemp`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`) VALUES (4,1,6,' NOTEBOOK',12,' SAMSUNG','SXD45','2344DF','WS345','','','',0,1,1,'187.154.214.190','dsl-187-154-214-190-dyn.prod-infinitum.com.mx',2,'2018-03-24 11:35:10',2,'2018-03-24 11:35:42'),(5,2,5,' TV',13,' SONY','UA4522','XM51122','4045','','','',0,1,1,'187.154.205.244','dsl-187-154-205-244-dyn.prod-infinitum.com.mx',1,'2018-04-04 11:36:44',1,'2018-04-04 11:37:49'),(6,2,33,' CONTROL REMOTO',13,' SONY','---','---','---','','','',0,1,1,'187.154.205.244','dsl-187-154-205-244-dyn.prod-infinitum.com.mx',1,'2018-04-04 11:43:38',0,'2018-04-04 11:43:38'),(13,9,0,'',0,'','','','','','','',0,1,1,'189.148.158.183','dsl-189-148-158-183-dyn.prod-infinitum.com.mx',1,'2018-04-07 17:51:29',0,'2018-04-07 17:51:29');
/*!40000 ALTER TABLE `control_detalle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `control_importe`
--

DROP TABLE IF EXISTS `control_importe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `control_importe` (
  `idimporte` int(10) NOT NULL AUTO_INCREMENT,
  `idcontrolmaster` int(10) DEFAULT '0',
  `cantidad` decimal(10,2) DEFAULT '0.00',
  `idprecio` int(10) NOT NULL DEFAULT '0',
  `codigo` varchar(25) DEFAULT '',
  `precio_unitario` decimal(10,2) NOT NULL DEFAULT '0.00',
  `viaticos` decimal(10,2) NOT NULL DEFAULT '0.00',
  `importe` decimal(10,2) DEFAULT '0.00',
  `contar` int(2) DEFAULT '0',
  `obs_viaticos` varchar(250) NOT NULL DEFAULT '',
  `observaciones` varchar(250) NOT NULL DEFAULT '',
  `status_importe` tinyint(1) NOT NULL DEFAULT '1',
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `host` varchar(100) NOT NULL DEFAULT '',
  `creado_por` int(10) DEFAULT '0',
  `creado_el` datetime DEFAULT CURRENT_TIMESTAMP,
  `modi_por` int(10) DEFAULT '0',
  `modi_el` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idimporte`),
  UNIQUE KEY `ControlCodigo` (`idcontrolmaster`,`idprecio`),
  KEY `idcontrol` (`idcontrolmaster`,`codigo`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `control_importe`
--

LOCK TABLES `control_importe` WRITE;
/*!40000 ALTER TABLE `control_importe` DISABLE KEYS */;
INSERT INTO `control_importe` (`idimporte`, `idcontrolmaster`, `cantidad`, `idprecio`, `codigo`, `precio_unitario`, `viaticos`, `importe`, `contar`, `obs_viaticos`, `observaciones`, `status_importe`, `idemp`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`) VALUES (6,1,2.00,1,'servac1',580.00,0.00,1160.00,0,'','más Viaticos',1,1,'187.154.214.190','dsl-187-154-214-190-dyn.prod-infinitum.com.mx',2,'2018-03-24 11:47:45',0,'2018-03-24 11:47:45'),(15,9,0.00,0,'',0.00,0.00,0.00,0,'','',1,1,'189.148.158.183','dsl-189-148-158-183-dyn.prod-infinitum.com.mx',1,'2018-04-07 17:51:29',0,'2018-04-07 17:51:29'),(8,2,1.00,1,'servac1',580.00,0.00,580.00,0,'','',1,1,'187.154.205.244','dsl-187-154-205-244-dyn.prod-infinitum.com.mx',1,'2018-04-04 11:45:36',0,'2018-04-04 11:45:36');
/*!40000 ALTER TABLE `control_importe` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`imsg`@`localhost`*/ /*!50003 TRIGGER `BEFORE_INSERT_control_importe` BEFORE INSERT ON `control_importe` FOR EACH ROW BEGIN

	SET new.importe = (new.cantidad * new.precio_unitario) + new.viaticos;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`imsg`@`localhost`*/ /*!50003 TRIGGER `BEFORE_UPDATE_control_importe` BEFORE UPDATE ON `control_importe` FOR EACH ROW BEGIN

	SET new.importe = (new.cantidad * new.precio_unitario) + new.viaticos;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `control_master`
--

DROP TABLE IF EXISTS `control_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `control_master` (
  `idcontrolmaster` int(10) NOT NULL AUTO_INCREMENT,
  `idempresa` int(10) NOT NULL DEFAULT '0',
  `idmodulo` int(10) DEFAULT '0',
  `idcliente` int(10) DEFAULT '0',
  `idtecnico` int(10) DEFAULT '0',
  `idrecibio` int(10) DEFAULT '0',
  `responsable` varchar(75) DEFAULT '',
  `garantia` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=No, 1=Si',
  `contrato` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=No, 1=Si',
  `tipo` smallint(1) DEFAULT '1' COMMENT '0=Externo, 1=Interno',
  `mantto` smallint(1) DEFAULT '0' COMMENT '0=Preventivo, 1=Correctivo',
  `fentrada` date DEFAULT NULL,
  `hora` time DEFAULT NULL,
  `fsalida` datetime DEFAULT '0000-00-00 00:00:00',
  `folgen` int(10) DEFAULT '0',
  `folmod` int(10) DEFAULT '0',
  `cargo` decimal(10,2) DEFAULT '0.00',
  `status` tinyint(1) DEFAULT '0',
  `no_venta` varchar(15) DEFAULT '',
  `no_factura` varchar(15) DEFAULT '',
  `falla` varchar(250) DEFAULT '',
  `accesorios` varchar(250) DEFAULT '',
  `observaciones` text,
  `trabajo` varchar(250) DEFAULT '',
  `comment` varchar(250) DEFAULT '',
  `idclienterecibioentrega` int(10) NOT NULL DEFAULT '0',
  `idtecnicoentrego` int(10) NOT NULL DEFAULT '0',
  `status_master` tinyint(1) NOT NULL DEFAULT '1',
  `status_anterior` varchar(25) NOT NULL,
  `status_actual` varchar(25) NOT NULL,
  `fecha_change_status` datetime DEFAULT NULL,
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL,
  `host` varchar(100) NOT NULL,
  `creado_por` int(10) DEFAULT '0',
  `creado_el` datetime DEFAULT CURRENT_TIMESTAMP,
  `modi_por` int(10) DEFAULT '0',
  `modi_el` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`idcontrolmaster`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `control_master`
--

LOCK TABLES `control_master` WRITE;
/*!40000 ALTER TABLE `control_master` DISABLE KEYS */;
INSERT INTO `control_master` (`idcontrolmaster`, `idempresa`, `idmodulo`, `idcliente`, `idtecnico`, `idrecibio`, `responsable`, `garantia`, `contrato`, `tipo`, `mantto`, `fentrada`, `hora`, `fsalida`, `folgen`, `folmod`, `cargo`, `status`, `no_venta`, `no_factura`, `falla`, `accesorios`, `observaciones`, `trabajo`, `comment`, `idclienterecibioentrega`, `idtecnicoentrego`, `status_master`, `status_anterior`, `status_actual`, `fecha_change_status`, `idemp`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`) VALUES (1,15,12,8,18,18,'',0,0,1,0,'2018-03-24','11:35:10','2018-04-03 19:14:38',0,4,0.00,9,'','','ALGO LE DUELE','CABLE INTERNO','TODO OK.','REPARACIÓN DEL EQUIPO','',8,18,1,'NO INICIADO              ','EN ESPERA DE REFACCION   ','2018-04-07 17:53:55',1,'189.148.158.183','dsl-189-148-158-183-dyn.prod-infinitum.com.mx',2,'2018-03-24 11:35:10',1,'2018-04-07 17:53:55'),(2,17,8,14,18,18,'',0,0,1,0,'2018-04-04','11:36:44','0000-00-00 00:00:00',0,23567,0.00,6,'','','SE VE PIXELEADO','BASE Y TORNILLO DE BASE','EL CLIENTE DIJO QUE SE LE MARCARA MAÑANA TEMPRANO','','',0,0,1,'EN ESPERA DE AUTORIZACION','AUTORIZADO               ','2018-04-07 17:55:06',1,'189.148.158.183','dsl-189-148-158-183-dyn.prod-infinitum.com.mx',1,'2018-04-04 11:36:44',1,'2018-04-07 17:55:06'),(9,17,4,14,8,8,'',0,0,1,0,'2018-04-07','17:51:29','0000-00-00 00:00:00',0,0,0.00,2,'','','','',NULL,'','',0,0,1,'NO INICIADO              ','EN REVISION              ','2018-04-07 17:51:54',1,'189.148.158.183','dsl-189-148-158-183-dyn.prod-infinitum.com.mx',1,'2018-04-07 17:51:29',1,'2018-04-07 17:51:54');
/*!40000 ALTER TABLE `control_master` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`imsg`@`localhost`*/ /*!50003 TRIGGER `BEFORE_INSERT_control_master` BEFORE INSERT ON `control_master` FOR EACH ROW BEGIN

	SET new.fentrada = NOW();
    SET new.hora = NOW();
	SET new.folgen = new.idcontrolmaster;

    SET @FM = (SELECT MAX(folmod) as maximo
               FROM control_master 
               WHERE idmodulo = new.idmodulo AND 
              		 idemp = new.idemp);

    SET new.folmod = @FM + 1;          

	SET @StatusActual = (
           SELECT descripcion 
           FROM cat_colores 
           WHERE idcolor = new.status limit 1);       

    SET new.status_actual = @StatusActual;
    SET new.fecha_change_status = NOW();

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`imsg`@`localhost`*/ /*!50003 TRIGGER `AFTER_INSERT_control_master` AFTER INSERT ON `control_master` FOR EACH ROW BEGIN

	Insert Into control_importe(idcontrolmaster,idemp,ip,host,creado_por,creado_el)
    values(new.idcontrolmaster,new.idemp,new.ip,new.host,new.creado_por,NOW());

	Insert Into control_detalle(idcontrolmaster,idemp,ip,host,creado_por,creado_el)
    values(new.idcontrolmaster,new.idemp,new.ip,new.host,new.creado_por,NOW());

	INSERT INTO control_status_log(
        idcontrolmaster,idcolor,idemp,ip,host,creado_por
        )VALUES(
           new.idcontrolmaster,new.status,new.idemp,new.ip,
       	 new.host,new.creado_por);
         
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`imsg`@`localhost`*/ /*!50003 TRIGGER `BEFORE_UPDATE_control_master` BEFORE UPDATE ON `control_master` FOR EACH ROW BEGIN

SET @IDCML = (
    SELECT MAX( idcontrolstatuslog) as idcontrolstatuslog
	FROM control_status_log
    WHERE idcontrolmaster = new.idcontrolmaster
	GROUP BY idcontrolmaster
    HAVING idcontrolmaster = new.idcontrolmaster
    );
         
SET @A = (SELECT idcolor
          FROM control_status_log
          WHERE idcontrolstatuslog = @IDCML);

IF (@A != new.status) THEN

	SET @StatusAterior = (
    	SELECT descripcion 
        FROM cat_colores 
        WHERE idcolor = @A limit 1);

	SET @StatusActual = (
    	SELECT descripcion 
        FROM cat_colores 
        WHERE idcolor = new.status limit 1);
           
    SET new.status_anterior = @StatusAterior;
    SET	new.status_actual = @StatusActual;
    SET	new.fecha_change_status = NOW();

END IF;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`imsg`@`localhost`*/ /*!50003 TRIGGER `AFTER_UPDATE_control_master` AFTER UPDATE ON `control_master` FOR EACH ROW BEGIN

SET @IDCML = (
    SELECT MAX( idcontrolstatuslog) as idcontrolstatuslog
	FROM control_status_log
    WHERE idcontrolmaster = new.idcontrolmaster
	GROUP BY idcontrolmaster
    HAVING idcontrolmaster = new.idcontrolmaster
    );
         
SET @A = (SELECT idcolor
          FROM control_status_log
          WHERE idcontrolstatuslog = @IDCML);

IF (@A != new.status) THEN

	INSERT INTO
   control_status_log
   (idcontrolmaster,
    idcolor,
    idemp,
    ip,
    host,
    creado_por
   )         
   VALUES 
   (new.idcontrolmaster,
    new.status,
    new.idemp,
    new.ip,
    new.host,
    new.creado_por
   );
                
ELSE 
	SET @X = (SELECT idcontrolmaster
         FROM control_status_log
         WHERE idcontrolmaster = new.idcontrolmaster limit 1);

    IF @X IS NULL THEN

        INSERT INTO
       control_status_log
       (idcontrolmaster,
        idcolor,
        idemp,
        ip,
        host,
        creado_por
       )         
       VALUES 
       (new.idcontrolmaster,
        new.status,
        new.idemp,
        new.ip,
        new.host,
        new.creado_por
       );
/*       
       SET @StatusActual = (
           SELECT descripcion 
           FROM cat_colores 
           WHERE idcolor = new.status limit 1);
           
           UPDATE control_master 
           SET 
           		status_aterior = "",
                status_actual = @StatusActual,
                fecha_change_status = NOW()
           WHERE idcontrolmaster = NEW.idcontrolmaster;     
*/       

    END IF;


END IF;



END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`imsg`@`localhost`*/ /*!50003 TRIGGER `BEFORE_DELETE_control_master` BEFORE DELETE ON `control_master` FOR EACH ROW BEGIN

	DELETE FROM control_importe 
    WHERE idcontrolmaster = old.idcontrolmaster;

	DELETE FROM control_detalle 
    WHERE idcontrolmaster = old.idcontrolmaster;

	DELETE FROM control_status_log 
    WHERE idcontrolmaster = old.idcontrolmaster;

	DELETE FROM control_comentarios 
    WHERE idcontrolmaster = old.idcontrolmaster;

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `control_status_log`
--

DROP TABLE IF EXISTS `control_status_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `control_status_log` (
  `idcontrolstatuslog` int(10) NOT NULL AUTO_INCREMENT,
  `idcontrolmaster` int(10) NOT NULL DEFAULT '0',
  `idcolor` int(10) NOT NULL DEFAULT '0',
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `host` varchar(100) NOT NULL DEFAULT '',
  `creado_por` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idcontrolstatuslog`),
  KEY `idcontrolmaster` (`idcontrolmaster`),
  KEY `idcmidcolor` (`idcontrolmaster`,`idcolor`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COMMENT='Lleva el registro de los cambios del og que se van presentan';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `control_status_log`
--

LOCK TABLES `control_status_log` WRITE;
/*!40000 ALTER TABLE `control_status_log` DISABLE KEYS */;
INSERT INTO `control_status_log` (`idcontrolstatuslog`, `idcontrolmaster`, `idcolor`, `fecha`, `idemp`, `ip`, `host`, `creado_por`) VALUES (1,2,2,'2018-04-07 09:37:23',1,'189.148.158.183','dsl-189-148-158-183-dyn.prod-infinitum.com.mx',1),(2,2,4,'2018-04-07 09:40:13',1,'189.148.158.183','dsl-189-148-158-183-dyn.prod-infinitum.com.mx',1),(7,2,7,'2018-04-07 17:08:31',1,'189.148.158.183','dsl-189-148-158-183-dyn.prod-infinitum.com.mx',1),(8,2,4,'2018-04-07 17:08:43',1,'189.148.158.183','dsl-189-148-158-183-dyn.prod-infinitum.com.mx',1),(15,9,1,'2018-04-07 17:51:29',1,'189.148.158.183','dsl-189-148-158-183-dyn.prod-infinitum.com.mx',1),(16,9,2,'2018-04-07 17:51:54',1,'189.148.158.183','dsl-189-148-158-183-dyn.prod-infinitum.com.mx',1),(17,1,11,'2018-04-07 17:52:40',1,'189.148.158.183','dsl-189-148-158-183-dyn.prod-infinitum.com.mx',2),(18,1,9,'2018-04-07 17:53:55',1,'189.148.158.183','dsl-189-148-158-183-dyn.prod-infinitum.com.mx',2),(19,2,5,'2018-04-07 17:54:07',1,'189.148.158.183','dsl-189-148-158-183-dyn.prod-infinitum.com.mx',1),(20,2,6,'2018-04-07 17:55:06',1,'189.148.158.183','dsl-189-148-158-183-dyn.prod-infinitum.com.mx',1);
/*!40000 ALTER TABLE `control_status_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cotizacion`
--

DROP TABLE IF EXISTS `cotizacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cotizacion` (
  `idcotizacion` int(10) NOT NULL AUTO_INCREMENT,
  `idcontrolmaster` int(10) DEFAULT '0',
  `codigo` varchar(15) DEFAULT '_codigo_',
  `cantidad` decimal(10,2) DEFAULT '0.00',
  `descripcion` varchar(250) DEFAULT NULL,
  `precio_costo` decimal(10,2) DEFAULT NULL,
  `proc_incremento` decimal(5,2) DEFAULT '0.70',
  `flete` decimal(10,2) DEFAULT NULL,
  `precio_venta` decimal(10,2) DEFAULT NULL,
  `importe` decimal(10,2) DEFAULT NULL,
  `proveedor` varchar(35) DEFAULT NULL,
  `status_cotizacion` tinyint(1) NOT NULL DEFAULT '1',
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL,
  `host` varchar(100) NOT NULL,
  `creado_por` int(10) DEFAULT NULL,
  `creado_el` datetime DEFAULT NULL,
  `modi_por` int(10) DEFAULT NULL,
  `modi_el` datetime DEFAULT NULL,
  PRIMARY KEY (`idcotizacion`),
  KEY `idcontrol` (`idcontrolmaster`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cotizacion`
--

LOCK TABLES `cotizacion` WRITE;
/*!40000 ALTER TABLE `cotizacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `cotizacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empresa`
--

DROP TABLE IF EXISTS `empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empresa` (
  `idemp` int(10) NOT NULL AUTO_INCREMENT,
  `rs` varchar(150) NOT NULL DEFAULT '',
  `ncomer` varchar(100) NOT NULL DEFAULT '',
  `df` varchar(200) NOT NULL DEFAULT '',
  `rfc` varchar(20) NOT NULL DEFAULT '',
  `logo` varchar(100) NOT NULL,
  PRIMARY KEY (`idemp`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='Catálogo de Empresas';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresa`
--

LOCK TABLES `empresa` WRITE;
/*!40000 ALTER TABLE `empresa` DISABLE KEYS */;
INSERT INTO `empresa` (`idemp`, `rs`, `ncomer`, `df`, `rfc`, `logo`) VALUES (1,'IMSG','IMSG','IMSG','IMSG','');
/*!40000 ALTER TABLE `empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empresas_reptte_legal`
--

DROP TABLE IF EXISTS `empresas_reptte_legal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empresas_reptte_legal` (
  `idempresarepresentantelegal` int(10) NOT NULL AUTO_INCREMENT,
  `idrepresentantelegal` int(10) NOT NULL DEFAULT '0',
  `idempresa` int(10) NOT NULL DEFAULT '0',
  `status_empresa_reptte_legal` tinyint(2) NOT NULL DEFAULT '1',
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL DEFAULT '',
  `host` varchar(100) NOT NULL DEFAULT '',
  `creado_por` int(10) NOT NULL DEFAULT '0',
  `creado_el` datetime NOT NULL,
  `modi_por` int(10) NOT NULL DEFAULT '0',
  `modi_el` datetime NOT NULL,
  PRIMARY KEY (`idempresarepresentantelegal`),
  UNIQUE KEY `emprepteemp` (`idrepresentantelegal`,`idempresa`,`idemp`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COMMENT='Relación Empresa -> Representante Legal';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresas_reptte_legal`
--

LOCK TABLES `empresas_reptte_legal` WRITE;
/*!40000 ALTER TABLE `empresas_reptte_legal` DISABLE KEYS */;
INSERT INTO `empresas_reptte_legal` (`idempresarepresentantelegal`, `idrepresentantelegal`, `idempresa`, `status_empresa_reptte_legal`, `idemp`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`) VALUES (7,8,15,1,1,'187.154.214.190','dsl-187-154-214-190-dyn.prod-infinitum.com.mx',2,'2018-03-24 11:33:16',0,'0000-00-00 00:00:00'),(6,9,15,1,1,'187.154.214.190','dsl-187-154-214-190-dyn.prod-infinitum.com.mx',2,'2018-03-24 11:33:16',0,'0000-00-00 00:00:00'),(8,11,3,1,1,'187.154.214.190','dsl-187-154-214-190-dyn.prod-infinitum.com.mx',2,'2018-03-24 12:22:33',0,'0000-00-00 00:00:00'),(9,14,16,1,1,'187.154.214.190','dsl-187-154-214-190-dyn.prod-infinitum.com.mx',2,'2018-03-24 12:47:16',0,'0000-00-00 00:00:00'),(11,14,17,1,1,'187.154.205.244','dsl-187-154-205-244-dyn.prod-infinitum.com.mx',1,'2018-04-04 11:53:24',0,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `empresas_reptte_legal` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`imsg`@`localhost`*/ /*!50003 TRIGGER `BEFORE_DELETE_empresas_reptte_legal` BEFORE DELETE ON `empresas_reptte_legal` FOR EACH ROW BEGIN

    SET @X = (
        SELECT idcontrolmaster 
        FROM control_master
        WHERE (idempresa = old.idempresa AND 
               idcliente = old.idrepresentantelegal)
        OR
        (idempresa = old.idempresa AND 
         idclienterecibioentrega = old.idrepresentantelegal)
        LIMIT 1);

    IF @X > 0 THEN

        DELETE FROM `Ya no se puede quitar este elemento.`
        WHERE x = -1;

    END IF; 


END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `empresas_tecnicos`
--

DROP TABLE IF EXISTS `empresas_tecnicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empresas_tecnicos` (
  `idempresatecnico` int(10) NOT NULL AUTO_INCREMENT,
  `idempresa` int(10) NOT NULL DEFAULT '0',
  `idtecnico` int(10) NOT NULL DEFAULT '0',
  `status_empresa_tecnico` tinyint(2) NOT NULL DEFAULT '1',
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL,
  `host` varchar(100) NOT NULL,
  `creado_por` int(10) NOT NULL DEFAULT '0',
  `creado_el` datetime NOT NULL,
  `modi_por` int(10) NOT NULL DEFAULT '0',
  `modi_el` datetime NOT NULL,
  PRIMARY KEY (`idempresatecnico`),
  UNIQUE KEY `emptotec` (`idempresa`,`idtecnico`,`idemp`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='Relación de Empresa -> Técnico';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresas_tecnicos`
--

LOCK TABLES `empresas_tecnicos` WRITE;
/*!40000 ALTER TABLE `empresas_tecnicos` DISABLE KEYS */;
INSERT INTO `empresas_tecnicos` (`idempresatecnico`, `idempresa`, `idtecnico`, `status_empresa_tecnico`, `idemp`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`) VALUES (13,17,8,1,1,'187.154.205.244','dsl-187-154-205-244-dyn.prod-infinitum.com.mx',1,'2018-04-04 11:34:44',0,'0000-00-00 00:00:00'),(12,17,18,1,1,'187.154.205.244','dsl-187-154-205-244-dyn.prod-infinitum.com.mx',1,'2018-04-04 11:34:44',0,'0000-00-00 00:00:00'),(8,15,18,1,1,'187.154.214.190','dsl-187-154-214-190-dyn.prod-infinitum.com.mx',2,'2018-03-24 11:33:28',0,'0000-00-00 00:00:00'),(10,3,18,1,1,'187.154.214.190','dsl-187-154-214-190-dyn.prod-infinitum.com.mx',2,'2018-03-24 12:22:54',0,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `empresas_tecnicos` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`imsg`@`localhost`*/ /*!50003 TRIGGER `BEFORE_DELETE_empresas_tecnicos` BEFORE DELETE ON `empresas_tecnicos` FOR EACH ROW BEGIN

    SET @X = (
        SELECT idcontrolmaster 
        FROM control_master
        WHERE (idempresa = old.idempresa AND 
               idtecnico = old.idtecnico)
        OR
        (idempresa = old.idempresa AND 
         idrecibio = old.idtecnico)
        OR
        (idempresa = old.idempresa AND 
         idtecnicoentrego = old.idtecnico)
        LIMIT 1);

    IF @X > 0 THEN

        DELETE FROM `Ya no se puede quitar este elemento.`
        WHERE x = -1;

    END IF; 

END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `exclusivo`
--

DROP TABLE IF EXISTS `exclusivo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exclusivo` (
  `idexclusivo` int(10) NOT NULL AUTO_INCREMENT,
  `idcontrolmaster` int(10) DEFAULT '0',
  `dilevery` varchar(30) DEFAULT NULL,
  `fecha_ped` date DEFAULT NULL,
  `rec_ref` varchar(30) DEFAULT NULL,
  `retail` varchar(50) DEFAULT NULL,
  `tag` varchar(30) DEFAULT NULL,
  `env_ref` varchar(30) DEFAULT NULL,
  `tag_doa` varchar(30) DEFAULT NULL,
  `env_ref_doa` varchar(30) DEFAULT NULL,
  `rec_ref_doa` varchar(30) DEFAULT NULL,
  `parte1` varchar(30) DEFAULT NULL,
  `serie1` varchar(30) DEFAULT NULL,
  `descrip1` varchar(50) DEFAULT NULL,
  `parte2` varchar(30) DEFAULT NULL,
  `serie2` varchar(30) DEFAULT NULL,
  `descrip2` varchar(30) DEFAULT NULL,
  `parte3` varchar(30) DEFAULT NULL,
  `serie3` varchar(30) DEFAULT NULL,
  `descrip3` varchar(30) DEFAULT NULL,
  `fecenvio` date DEFAULT NULL,
  `guienvio` varchar(50) DEFAULT NULL,
  `folenvio` varchar(30) DEFAULT NULL,
  `fcompra` date DEFAULT NULL,
  `venpor` varchar(50) DEFAULT NULL,
  `fsol` date DEFAULT NULL,
  `frecibido` date DEFAULT NULL,
  `numped` varchar(30) DEFAULT NULL,
  `genvioref` varchar(30) DEFAULT NULL,
  `fentrega` date DEFAULT NULL,
  `statusfol` varchar(20) DEFAULT NULL,
  `mail` varchar(50) DEFAULT NULL,
  `frepara` date DEFAULT NULL,
  `status_exclusivo` tinyint(1) NOT NULL DEFAULT '1',
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL,
  `host` varchar(100) NOT NULL,
  `creado_por` int(10) DEFAULT NULL,
  `creado_el` datetime DEFAULT NULL,
  `modi_por` int(10) DEFAULT NULL,
  `modi_el` datetime DEFAULT NULL,
  PRIMARY KEY (`idexclusivo`),
  KEY `idcontrol` (`idcontrolmaster`),
  KEY `controlexclusivo` (`idexclusivo`,`idcontrolmaster`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exclusivo`
--

LOCK TABLES `exclusivo` WRITE;
/*!40000 ALTER TABLE `exclusivo` DISABLE KEYS */;
/*!40000 ALTER TABLE `exclusivo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lockid`
--

DROP TABLE IF EXISTS `lockid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lockid` (
  `idlock` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tabla` varchar(20) NOT NULL DEFAULT '',
  `clave` int(10) NOT NULL DEFAULT '0',
  `status_lockid` tinyint(1) NOT NULL DEFAULT '1',
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL,
  `host` varchar(100) NOT NULL,
  `creado_por` int(6) NOT NULL DEFAULT '0',
  `creado_el` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modi_por` int(5) NOT NULL DEFAULT '0',
  `modi_el` datetime NOT NULL,
  PRIMARY KEY (`idlock`),
  KEY `tabla` (`tabla`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Bloqueo de Folios en Tablas';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lockid`
--

LOCK TABLES `lockid` WRITE;
/*!40000 ALTER TABLE `lockid` DISABLE KEYS */;
/*!40000 ALTER TABLE `lockid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `idlog` int(10) NOT NULL AUTO_INCREMENT,
  `iduser` int(10) NOT NULL,
  `usuario` varchar(20) NOT NULL,
  `date_mov` datetime NOT NULL,
  `typemov` varchar(20) NOT NULL,
  `table_mov` varchar(50) NOT NULL,
  `idkey` int(10) NOT NULL,
  `fieldkey` varchar(100) NOT NULL,
  PRIMARY KEY (`idlog`)
) ENGINE=MyISAM AUTO_INCREMENT=462 DEFAULT CHARSET=utf8 COMMENT='Guarda el log de operaciones';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
INSERT INTO `logs` (`idlog`, `iduser`, `usuario`, `date_mov`, `typemov`, `table_mov`, `idkey`, `fieldkey`) VALUES (1,1,'','2018-01-19 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(2,3,'','2018-01-19 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(3,6,'','2018-01-19 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(4,2,'','2018-01-19 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(5,8,'','2018-01-19 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(6,8,'','2018-01-19 10:22:37','Conectado','Usuarios Conectados',8,'iduser'),(7,8,'','2018-01-19 18:22:04','Desconectado','Usuarios Conectados',8,'iduser'),(8,2,'','2018-01-19 18:22:22','Conectado','Usuarios Conectados',2,'iduser'),(9,8,'','2018-01-19 18:23:47','Conectado','Usuarios Conectados',8,'iduser'),(10,2,'','2018-01-19 19:07:07','Desconectado','Usuarios Conectados',2,'iduser'),(11,2,'','2018-01-19 19:07:16','Conectado','Usuarios Conectados',2,'iduser'),(12,2,'','2018-01-19 19:45:54','Desconectado','Usuarios Conectados',2,'iduser'),(13,1,'','2018-01-20 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(14,3,'','2018-01-20 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(15,6,'','2018-01-20 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(16,2,'','2018-01-20 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(17,8,'','2018-01-20 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(18,1,'','2018-01-21 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(19,3,'','2018-01-21 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(20,6,'','2018-01-21 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(21,2,'','2018-01-21 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(22,8,'','2018-01-21 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(23,1,'','2018-01-22 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(24,3,'','2018-01-22 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(25,6,'','2018-01-22 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(26,2,'','2018-01-22 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(27,8,'','2018-01-22 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(28,8,'','2018-01-22 10:37:17','Conectado','Usuarios Conectados',8,'iduser'),(29,8,'','2018-01-22 10:49:42','Desconectado','Usuarios Conectados',8,'iduser'),(30,8,'','2018-01-22 11:09:57','Conectado','Usuarios Conectados',8,'iduser'),(31,8,'','2018-01-22 14:00:22','Desconectado','Usuarios Conectados',8,'iduser'),(32,8,'','2018-01-22 14:01:15','Conectado','Usuarios Conectados',8,'iduser'),(33,1,'','2018-01-23 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(34,3,'','2018-01-23 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(35,6,'','2018-01-23 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(36,2,'','2018-01-23 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(37,8,'','2018-01-23 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(38,8,'','2018-01-23 10:12:02','Conectado','Usuarios Conectados',8,'iduser'),(39,1,'','2018-01-24 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(40,3,'','2018-01-24 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(41,6,'','2018-01-24 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(42,2,'','2018-01-24 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(43,8,'','2018-01-24 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(44,1,'','2018-01-25 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(45,3,'','2018-01-25 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(46,6,'','2018-01-25 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(47,2,'','2018-01-25 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(48,8,'','2018-01-25 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(49,1,'','2018-01-26 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(50,3,'','2018-01-26 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(51,6,'','2018-01-26 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(52,2,'','2018-01-26 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(53,8,'','2018-01-26 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(54,1,'','2018-01-27 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(55,3,'','2018-01-27 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(56,6,'','2018-01-27 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(57,2,'','2018-01-27 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(58,8,'','2018-01-27 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(59,1,'','2018-01-28 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(60,3,'','2018-01-28 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(61,6,'','2018-01-28 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(62,2,'','2018-01-28 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(63,8,'','2018-01-28 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(64,1,'','2018-01-29 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(65,3,'','2018-01-29 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(66,6,'','2018-01-29 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(67,2,'','2018-01-29 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(68,8,'','2018-01-29 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(69,1,'','2018-01-30 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(70,3,'','2018-01-30 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(71,6,'','2018-01-30 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(72,2,'','2018-01-30 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(73,8,'','2018-01-30 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(74,1,'','2018-01-31 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(75,3,'','2018-01-31 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(76,6,'','2018-01-31 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(77,2,'','2018-01-31 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(78,8,'','2018-01-31 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(79,1,'','2018-02-01 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(80,3,'','2018-02-01 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(81,6,'','2018-02-01 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(82,2,'','2018-02-01 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(83,8,'','2018-02-01 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(84,1,'','2018-02-02 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(85,3,'','2018-02-02 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(86,6,'','2018-02-02 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(87,2,'','2018-02-02 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(88,8,'','2018-02-02 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(89,1,'','2018-02-03 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(90,3,'','2018-02-03 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(91,6,'','2018-02-03 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(92,2,'','2018-02-03 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(93,8,'','2018-02-03 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(94,1,'','2018-02-04 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(95,3,'','2018-02-04 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(96,6,'','2018-02-04 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(97,2,'','2018-02-04 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(98,8,'','2018-02-04 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(99,1,'','2018-02-05 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(100,3,'','2018-02-05 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(101,6,'','2018-02-05 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(102,2,'','2018-02-05 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(103,8,'','2018-02-05 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(104,1,'','2018-02-06 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(105,3,'','2018-02-06 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(106,6,'','2018-02-06 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(107,2,'','2018-02-06 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(108,8,'','2018-02-06 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(109,1,'','2018-02-07 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(110,3,'','2018-02-07 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(111,6,'','2018-02-07 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(112,2,'','2018-02-07 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(113,8,'','2018-02-07 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(114,1,'','2018-02-08 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(115,3,'','2018-02-08 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(116,6,'','2018-02-08 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(117,2,'','2018-02-08 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(118,8,'','2018-02-08 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(119,1,'','2018-02-09 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(120,3,'','2018-02-09 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(121,6,'','2018-02-09 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(122,2,'','2018-02-09 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(123,8,'','2018-02-09 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(124,1,'','2018-02-10 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(125,3,'','2018-02-10 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(126,6,'','2018-02-10 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(127,2,'','2018-02-10 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(128,8,'','2018-02-10 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(129,1,'','2018-02-11 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(130,3,'','2018-02-11 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(131,6,'','2018-02-11 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(132,2,'','2018-02-11 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(133,8,'','2018-02-11 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(134,1,'','2018-02-12 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(135,3,'','2018-02-12 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(136,6,'','2018-02-12 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(137,2,'','2018-02-12 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(138,8,'','2018-02-12 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(139,1,'','2018-02-13 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(140,3,'','2018-02-13 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(141,6,'','2018-02-13 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(142,2,'','2018-02-13 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(143,8,'','2018-02-13 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(144,1,'','2018-02-14 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(145,3,'','2018-02-14 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(146,6,'','2018-02-14 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(147,2,'','2018-02-14 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(148,8,'','2018-02-14 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(149,1,'','2018-02-15 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(150,3,'','2018-02-15 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(151,6,'','2018-02-15 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(152,2,'','2018-02-15 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(153,8,'','2018-02-15 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(154,1,'','2018-02-16 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(155,3,'','2018-02-16 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(156,6,'','2018-02-16 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(157,2,'','2018-02-16 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(158,8,'','2018-02-16 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(159,1,'','2018-02-17 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(160,3,'','2018-02-17 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(161,6,'','2018-02-17 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(162,2,'','2018-02-17 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(163,8,'','2018-02-17 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(164,1,'','2018-02-18 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(165,3,'','2018-02-18 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(166,6,'','2018-02-18 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(167,2,'','2018-02-18 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(168,8,'','2018-02-18 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(169,1,'','2018-02-19 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(170,3,'','2018-02-19 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(171,6,'','2018-02-19 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(172,2,'','2018-02-19 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(173,8,'','2018-02-19 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(174,1,'','2018-02-20 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(175,3,'','2018-02-20 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(176,6,'','2018-02-20 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(177,2,'','2018-02-20 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(178,8,'','2018-02-20 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(179,1,'','2018-02-21 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(180,3,'','2018-02-21 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(181,6,'','2018-02-21 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(182,2,'','2018-02-21 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(183,8,'','2018-02-21 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(184,1,'','2018-02-22 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(185,3,'','2018-02-22 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(186,6,'','2018-02-22 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(187,2,'','2018-02-22 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(188,8,'','2018-02-22 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(189,1,'','2018-02-23 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(190,3,'','2018-02-23 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(191,6,'','2018-02-23 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(192,2,'','2018-02-23 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(193,8,'','2018-02-23 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(194,1,'','2018-02-24 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(195,3,'','2018-02-24 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(196,6,'','2018-02-24 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(197,2,'','2018-02-24 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(198,8,'','2018-02-24 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(199,1,'','2018-02-25 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(200,3,'','2018-02-25 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(201,6,'','2018-02-25 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(202,2,'','2018-02-25 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(203,8,'','2018-02-25 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(204,1,'','2018-02-26 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(205,3,'','2018-02-26 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(206,6,'','2018-02-26 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(207,2,'','2018-02-26 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(208,8,'','2018-02-26 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(209,1,'','2018-02-27 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(210,3,'','2018-02-27 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(211,6,'','2018-02-27 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(212,2,'','2018-02-27 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(213,8,'','2018-02-27 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(214,1,'','2018-02-28 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(215,3,'','2018-02-28 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(216,6,'','2018-02-28 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(217,2,'','2018-02-28 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(218,8,'','2018-02-28 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(219,1,'','2018-03-01 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(220,3,'','2018-03-01 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(221,6,'','2018-03-01 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(222,2,'','2018-03-01 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(223,8,'','2018-03-01 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(224,1,'','2018-03-02 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(225,3,'','2018-03-02 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(226,6,'','2018-03-02 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(227,2,'','2018-03-02 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(228,8,'','2018-03-02 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(229,1,'','2018-03-03 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(230,3,'','2018-03-03 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(231,6,'','2018-03-03 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(232,2,'','2018-03-03 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(233,8,'','2018-03-03 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(234,1,'','2018-03-04 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(235,3,'','2018-03-04 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(236,6,'','2018-03-04 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(237,2,'','2018-03-04 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(238,8,'','2018-03-04 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(239,1,'','2018-03-05 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(240,3,'','2018-03-05 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(241,6,'','2018-03-05 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(242,2,'','2018-03-05 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(243,8,'','2018-03-05 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(244,1,'','2018-03-06 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(245,3,'','2018-03-06 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(246,6,'','2018-03-06 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(247,2,'','2018-03-06 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(248,8,'','2018-03-06 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(249,1,'','2018-03-07 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(250,3,'','2018-03-07 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(251,6,'','2018-03-07 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(252,2,'','2018-03-07 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(253,8,'','2018-03-07 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(254,1,'','2018-03-08 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(255,3,'','2018-03-08 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(256,6,'','2018-03-08 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(257,2,'','2018-03-08 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(258,8,'','2018-03-08 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(259,1,'','2018-03-09 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(260,3,'','2018-03-09 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(261,6,'','2018-03-09 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(262,2,'','2018-03-09 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(263,8,'','2018-03-09 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(264,1,'','2018-03-10 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(265,3,'','2018-03-10 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(266,6,'','2018-03-10 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(267,2,'','2018-03-10 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(268,8,'','2018-03-10 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(269,1,'','2018-03-11 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(270,3,'','2018-03-11 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(271,6,'','2018-03-11 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(272,2,'','2018-03-11 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(273,8,'','2018-03-11 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(274,1,'','2018-03-12 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(275,3,'','2018-03-12 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(276,6,'','2018-03-12 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(277,2,'','2018-03-12 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(278,8,'','2018-03-12 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(279,1,'','2018-03-13 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(280,3,'','2018-03-13 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(281,6,'','2018-03-13 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(282,2,'','2018-03-13 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(283,8,'','2018-03-13 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(284,1,'','2018-03-14 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(285,3,'','2018-03-14 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(286,6,'','2018-03-14 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(287,2,'','2018-03-14 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(288,8,'','2018-03-14 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(289,1,'','2018-03-15 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(290,3,'','2018-03-15 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(291,6,'','2018-03-15 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(292,2,'','2018-03-15 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(293,8,'','2018-03-15 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(294,1,'','2018-03-16 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(295,3,'','2018-03-16 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(296,6,'','2018-03-16 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(297,2,'','2018-03-16 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(298,8,'','2018-03-16 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(299,1,'','2018-03-17 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(300,3,'','2018-03-17 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(301,6,'','2018-03-17 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(302,2,'','2018-03-17 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(303,8,'','2018-03-17 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(304,1,'','2018-03-18 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(305,3,'','2018-03-18 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(306,6,'','2018-03-18 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(307,2,'','2018-03-18 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(308,8,'','2018-03-18 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(309,1,'','2018-03-19 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(310,3,'','2018-03-19 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(311,6,'','2018-03-19 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(312,2,'','2018-03-19 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(313,8,'','2018-03-19 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(314,1,'','2018-03-20 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(315,3,'','2018-03-20 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(316,6,'','2018-03-20 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(317,2,'','2018-03-20 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(318,8,'','2018-03-20 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(319,1,'','2018-03-21 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(320,3,'','2018-03-21 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(321,6,'','2018-03-21 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(322,2,'','2018-03-21 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(323,8,'','2018-03-21 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(324,1,'','2018-03-22 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(325,3,'','2018-03-22 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(326,6,'','2018-03-22 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(327,2,'','2018-03-22 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(328,8,'','2018-03-22 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(329,1,'','2018-03-23 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(330,3,'','2018-03-23 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(331,6,'','2018-03-23 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(332,2,'','2018-03-23 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(333,8,'','2018-03-23 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(334,2,'','2018-03-23 18:56:05','Conectado','Usuarios Conectados',2,'iduser'),(335,1,'','2018-03-24 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(336,3,'','2018-03-24 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(337,6,'','2018-03-24 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(338,2,'','2018-03-24 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(339,8,'','2018-03-24 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(340,2,'','2018-03-24 10:54:54','Conectado','Usuarios Conectados',2,'iduser'),(341,2,'','2018-03-24 11:00:12','Desconectado','Usuarios Conectados',2,'iduser'),(342,2,'','2018-03-24 11:02:18','Conectado','Usuarios Conectados',2,'iduser'),(343,2,'','2018-03-24 11:05:13','Desconectado','Usuarios Conectados',2,'iduser'),(344,11,'','2018-03-24 11:05:23','Init','Usuarios Conectados',11,'iduser'),(345,11,'','2018-03-24 11:05:34','Desconectado','Usuarios Conectados',11,'iduser'),(346,2,'','2018-03-24 11:05:37','Conectado','Usuarios Conectados',2,'iduser'),(347,2,'','2018-03-24 11:06:06','Desconectado','Usuarios Conectados',2,'iduser'),(348,11,'','2018-03-24 11:06:12','Conectado','Usuarios Conectados',11,'iduser'),(349,11,'','2018-03-24 11:06:29','Desconectado','Usuarios Conectados',11,'iduser'),(350,2,'','2018-03-24 11:06:49','Conectado','Usuarios Conectados',2,'iduser'),(351,2,'','2018-03-24 11:58:45','Desconectado','Usuarios Conectados',2,'iduser'),(352,2,'','2018-03-24 11:58:54','Conectado','Usuarios Conectados',2,'iduser'),(353,2,'','2018-03-24 12:40:54','Desconectado','Usuarios Conectados',2,'iduser'),(354,2,'','2018-03-24 12:43:13','Conectado','Usuarios Conectados',2,'iduser'),(355,2,'','2018-03-24 12:53:01','Desconectado','Usuarios Conectados',2,'iduser'),(356,1,'','2018-03-24 12:53:05','Conectado','Usuarios Conectados',1,'iduser'),(357,1,'','2018-03-25 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(358,3,'','2018-03-25 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(359,6,'','2018-03-25 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(360,2,'','2018-03-25 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(361,8,'','2018-03-25 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(362,11,'','2018-03-25 00:01:00','Desconectado','Usuarios Conectados',11,'iduser'),(363,1,'','2018-03-26 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(364,3,'','2018-03-26 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(365,6,'','2018-03-26 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(366,2,'','2018-03-26 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(367,8,'','2018-03-26 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(368,11,'','2018-03-26 00:01:00','Desconectado','Usuarios Conectados',11,'iduser'),(369,1,'','2018-03-27 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(370,3,'','2018-03-27 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(371,6,'','2018-03-27 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(372,2,'','2018-03-27 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(373,8,'','2018-03-27 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(374,11,'','2018-03-27 00:01:00','Desconectado','Usuarios Conectados',11,'iduser'),(375,1,'','2018-03-28 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(376,3,'','2018-03-28 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(377,6,'','2018-03-28 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(378,2,'','2018-03-28 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(379,8,'','2018-03-28 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(380,11,'','2018-03-28 00:01:00','Desconectado','Usuarios Conectados',11,'iduser'),(381,1,'','2018-03-28 12:03:19','Conectado','Usuarios Conectados',1,'iduser'),(382,1,'','2018-03-29 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(383,3,'','2018-03-29 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(384,6,'','2018-03-29 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(385,2,'','2018-03-29 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(386,8,'','2018-03-29 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(387,11,'','2018-03-29 00:01:00','Desconectado','Usuarios Conectados',11,'iduser'),(388,1,'','2018-03-30 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(389,3,'','2018-03-30 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(390,6,'','2018-03-30 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(391,2,'','2018-03-30 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(392,8,'','2018-03-30 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(393,11,'','2018-03-30 00:01:00','Desconectado','Usuarios Conectados',11,'iduser'),(394,1,'','2018-03-31 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(395,3,'','2018-03-31 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(396,6,'','2018-03-31 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(397,2,'','2018-03-31 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(398,8,'','2018-03-31 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(399,11,'','2018-03-31 00:01:00','Desconectado','Usuarios Conectados',11,'iduser'),(400,1,'','2018-04-01 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(401,3,'','2018-04-01 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(402,6,'','2018-04-01 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(403,2,'','2018-04-01 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(404,8,'','2018-04-01 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(405,11,'','2018-04-01 00:01:00','Desconectado','Usuarios Conectados',11,'iduser'),(406,1,'','2018-04-02 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(407,3,'','2018-04-02 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(408,6,'','2018-04-02 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(409,2,'','2018-04-02 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(410,8,'','2018-04-02 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(411,11,'','2018-04-02 00:01:00','Desconectado','Usuarios Conectados',11,'iduser'),(412,1,'','2018-04-03 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(413,3,'','2018-04-03 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(414,6,'','2018-04-03 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(415,2,'','2018-04-03 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(416,8,'','2018-04-03 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(417,11,'','2018-04-03 00:01:00','Desconectado','Usuarios Conectados',11,'iduser'),(418,1,'','2018-04-04 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(419,3,'','2018-04-04 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(420,6,'','2018-04-04 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(421,2,'','2018-04-04 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(422,8,'','2018-04-04 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(423,11,'','2018-04-04 00:01:00','Desconectado','Usuarios Conectados',11,'iduser'),(424,1,'','2018-04-04 11:25:32','Conectado','Usuarios Conectados',1,'iduser'),(425,1,'','2018-04-05 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(426,3,'','2018-04-05 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(427,6,'','2018-04-05 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(428,2,'','2018-04-05 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(429,8,'','2018-04-05 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(430,11,'','2018-04-05 00:01:00','Desconectado','Usuarios Conectados',11,'iduser'),(431,2,'','2018-04-05 19:50:23','Conectado','Usuarios Conectados',2,'iduser'),(432,1,'','2018-04-06 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(433,3,'','2018-04-06 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(434,6,'','2018-04-06 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(435,2,'','2018-04-06 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(436,8,'','2018-04-06 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(437,11,'','2018-04-06 00:01:00','Desconectado','Usuarios Conectados',11,'iduser'),(438,2,'','2018-04-06 08:16:11','Conectado','Usuarios Conectados',2,'iduser'),(439,2,'','2018-04-06 19:26:22','Desconectado','Usuarios Conectados',2,'iduser'),(440,1,'','2018-04-06 19:26:32','Conectado','Usuarios Conectados',1,'iduser'),(441,1,'','2018-04-06 20:17:51','Desconectado','Usuarios Conectados',1,'iduser'),(442,1,'','2018-04-06 20:25:29','Conectado','Usuarios Conectados',1,'iduser'),(443,1,'','2018-04-07 00:01:00','Desconectado','Usuarios Conectados',1,'iduser'),(444,3,'','2018-04-07 00:01:00','Desconectado','Usuarios Conectados',3,'iduser'),(445,6,'','2018-04-07 00:01:00','Desconectado','Usuarios Conectados',6,'iduser'),(446,2,'','2018-04-07 00:01:00','Desconectado','Usuarios Conectados',2,'iduser'),(447,8,'','2018-04-07 00:01:00','Desconectado','Usuarios Conectados',8,'iduser'),(448,11,'','2018-04-07 00:01:00','Desconectado','Usuarios Conectados',11,'iduser'),(449,2,'','2018-04-07 10:32:14','Conectado','Usuarios Conectados',2,'iduser'),(450,9,'','2018-04-07 10:36:27','Init','Usuarios Conectados',9,'iduser'),(451,22,'','2018-04-07 14:03:36','Init','Usuarios Conectados',22,'iduser'),(452,22,'','2018-04-07 14:05:36','Desconectado','Usuarios Conectados',22,'iduser'),(453,16,'','2018-04-07 14:05:56','Init','Usuarios Conectados',16,'iduser'),(454,16,'','2018-04-07 14:06:33','Desconectado','Usuarios Conectados',16,'iduser'),(455,22,'','2018-04-07 14:06:46','Conectado','Usuarios Conectados',22,'iduser'),(456,22,'','2018-04-07 14:09:31','Desconectado','Usuarios Conectados',22,'iduser'),(457,1,'','2018-04-07 16:31:46','Conectado','Usuarios Conectados',1,'iduser'),(458,1,'','2018-04-07 16:33:19','Desconectado','Usuarios Conectados',1,'iduser'),(459,22,'','2018-04-07 16:33:24','Conectado','Usuarios Conectados',22,'iduser'),(460,22,'','2018-04-07 16:34:44','Desconectado','Usuarios Conectados',22,'iduser'),(461,1,'','2018-04-07 16:34:48','Conectado','Usuarios Conectados',1,'iduser');
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `iduser` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(60) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `nombres` varchar(100) NOT NULL,
  `registro` varchar(15) NOT NULL,
  `especialidad` varchar(50) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `domicilio` varchar(150) NOT NULL,
  `colonia` varchar(100) NOT NULL,
  `municipio` varchar(50) NOT NULL,
  `estado` varchar(20) NOT NULL,
  `otrostel` varchar(100) NOT NULL,
  `teloficina` varchar(50) NOT NULL,
  `telpersonal` varchar(50) NOT NULL,
  `telfax` varchar(50) NOT NULL,
  `correoelectronico` varchar(100) NOT NULL,
  `idmunicipio` int(5) NOT NULL DEFAULT '0',
  `idestado` int(5) NOT NULL DEFAULT '0',
  `cedulaprofesional` varchar(20) NOT NULL,
  `registro_colegio` varchar(20) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `host` varchar(100) NOT NULL,
  `creado_por` int(5) NOT NULL DEFAULT '0',
  `creado_el` datetime NOT NULL,
  `modi_por` int(5) NOT NULL DEFAULT '0',
  `modi_el` datetime NOT NULL,
  `foto` varchar(100) NOT NULL,
  `p1` int(2) NOT NULL DEFAULT '0',
  `p2` int(2) NOT NULL DEFAULT '0',
  `p3` int(2) NOT NULL DEFAULT '0',
  `p4` int(2) NOT NULL DEFAULT '0',
  `p5` int(2) NOT NULL DEFAULT '0',
  `p6` int(2) NOT NULL DEFAULT '0',
  `p7` int(2) NOT NULL DEFAULT '0',
  `p8` int(2) NOT NULL DEFAULT '0',
  `p9` int(2) NOT NULL DEFAULT '0',
  `p10` int(2) NOT NULL DEFAULT '0',
  `p11` int(2) NOT NULL DEFAULT '0',
  `p12` int(2) NOT NULL DEFAULT '0',
  `p13` int(2) NOT NULL DEFAULT '0',
  `p14` int(2) NOT NULL DEFAULT '0',
  `p15` int(2) NOT NULL DEFAULT '0',
  `p16` int(2) NOT NULL DEFAULT '0',
  `p17` int(2) NOT NULL DEFAULT '0',
  `p18` int(2) NOT NULL DEFAULT '0',
  `p19` int(2) NOT NULL DEFAULT '0',
  `p20` int(2) NOT NULL DEFAULT '0',
  `p21` int(2) NOT NULL DEFAULT '0',
  `p22` int(2) NOT NULL DEFAULT '0',
  `p23` int(2) NOT NULL DEFAULT '0',
  `p24` int(2) NOT NULL DEFAULT '0',
  `p25` int(2) NOT NULL DEFAULT '0',
  `p26` int(2) NOT NULL DEFAULT '0',
  `p27` int(2) NOT NULL DEFAULT '0',
  `p28` int(2) NOT NULL DEFAULT '0',
  `p29` int(2) NOT NULL DEFAULT '0',
  `p30` int(2) NOT NULL DEFAULT '0',
  `p31` int(2) NOT NULL DEFAULT '0',
  `p32` int(2) NOT NULL DEFAULT '0',
  `p33` int(2) NOT NULL DEFAULT '0',
  `p34` int(2) NOT NULL DEFAULT '0',
  `p35` int(2) NOT NULL DEFAULT '0',
  `p36` int(2) NOT NULL DEFAULT '0',
  `p37` int(2) NOT NULL DEFAULT '0',
  `p38` int(2) NOT NULL DEFAULT '0',
  `p39` int(2) NOT NULL DEFAULT '0',
  `p40` int(2) NOT NULL DEFAULT '0',
  `p41` int(2) NOT NULL DEFAULT '0',
  `p42` int(2) NOT NULL DEFAULT '0',
  `p43` int(2) NOT NULL DEFAULT '0',
  `p44` int(2) NOT NULL DEFAULT '0',
  `p45` int(2) NOT NULL DEFAULT '0',
  `p46` int(2) NOT NULL DEFAULT '0',
  `p47` int(2) NOT NULL DEFAULT '0',
  `p48` int(2) NOT NULL DEFAULT '0',
  `p49` int(2) NOT NULL DEFAULT '0',
  `p50` int(2) NOT NULL DEFAULT '0',
  `idper` int(10) NOT NULL DEFAULT '0' COMMENT 'Id del Catalogo de Personal con quien esta relacionado',
  `idemp` int(10) NOT NULL DEFAULT '1',
  `idusernivelacceso` int(10) NOT NULL DEFAULT '5',
  `status_usuario` int(2) NOT NULL DEFAULT '1' COMMENT '0=Inactivo, 1=Activo',
  `token` varchar(60) DEFAULT '',
  `token_validated` int(2) NOT NULL DEFAULT '0' COMMENT '0=No, 1=Si',
  `token_source` varchar(60) NOT NULL DEFAULT '0',
  `registrosporpagina` int(3) NOT NULL DEFAULT '10',
  `param1` varchar(100) NOT NULL,
  PRIMARY KEY (`iduser`),
  UNIQUE KEY `up` (`username`,`password`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `useremp` (`username`,`idemp`),
  KEY `idemp` (`idemp`),
  KEY `idusernivelacceso` (`idusernivelacceso`),
  KEY `idper` (`idper`),
  KEY `status_usuario` (`status_usuario`),
  KEY `userpassstatus` (`username`,`password`,`status_usuario`),
  KEY `emostatu` (`idemp`,`status_usuario`),
  KEY `upes` (`username`,`password`,`idemp`,`status_usuario`),
  KEY `valid_token` (`token_validated`),
  KEY `token` (`token`),
  FULLTEXT KEY `apps` (`apellidos`),
  FULLTEXT KEY `nombresFull` (`nombres`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` (`iduser`, `username`, `password`, `apellidos`, `nombres`, `registro`, `especialidad`, `nombre`, `domicilio`, `colonia`, `municipio`, `estado`, `otrostel`, `teloficina`, `telpersonal`, `telfax`, `correoelectronico`, `idmunicipio`, `idestado`, `cedulaprofesional`, `registro_colegio`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`, `foto`, `p1`, `p2`, `p3`, `p4`, `p5`, `p6`, `p7`, `p8`, `p9`, `p10`, `p11`, `p12`, `p13`, `p14`, `p15`, `p16`, `p17`, `p18`, `p19`, `p20`, `p21`, `p22`, `p23`, `p24`, `p25`, `p26`, `p27`, `p28`, `p29`, `p30`, `p31`, `p32`, `p33`, `p34`, `p35`, `p36`, `p37`, `p38`, `p39`, `p40`, `p41`, `p42`, `p43`, `p44`, `p45`, `p46`, `p47`, `p48`, `p49`, `p50`, `idper`, `idemp`, `idusernivelacceso`, `status_usuario`, `token`, `token_validated`, `token_source`, `registrosporpagina`, `param1`) VALUES (1,'devch_imsg','202cb962ac59075b964b07152d234b70','HIDALGO','CARLOS','','','','','','','','','','','','',0,0,'','','','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1000,1,'',0,'e9108f525be2eda5d9b8acb931804397',10,''),(2,'dba','d693c4871a99d7acf43c4b1112da0c6e','Revueltas','José','','','','','','','','','','','','',0,0,'','','189.148.134.207','dsl-189-148-134-207-dyn.prod-infinitum.com.mx',1,'2017-07-04 16:01:33',1,'2018-03-28 13:11:05','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,'',0,'ae6ce8ebb3784e6370b5839c5fa4a6d1',10,''),(4,'im009999','380f75c664240a0e587c58751846bca4','MAGAÑA GASPAR','LUIS ARTURO','','','','','','','','','','','','luis_artmag@hotmail.com',0,0,'','','189.148.134.207','dsl-189-148-134-207-dyn.prod-infinitum.com.mx',0,'2017-08-17 19:56:38',1,'2018-03-28 13:10:52','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,5,1,'',0,'00e1350ecf0321229ce3f9495365c67a',10,''),(5,'im009997','7a5ea776b6f5e9c54ff8a916ea27527c','CORDOVA IZQUIERDO','PIEDAD DEL ROSARIO','','','','','','','','','','','','',0,0,'','','189.148.134.207','dsl-189-148-134-207-dyn.prod-infinitum.com.mx',0,'2017-08-17 20:04:59',1,'2018-03-28 13:10:42','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,5,1,'',0,'9fd2bf30c32454c994804ec63d8815dc',10,''),(6,'im009995','1a3f41899089df8b27154db1055fd507','ALFARO SALVADOR','KAREN','','','','','','','','','','','','alfaro15@hotmail.com',0,0,'','','189.148.134.207','dsl-189-148-134-207-dyn.prod-infinitum.com.mx',0,'2017-08-18 13:12:44',1,'2018-03-28 13:10:34','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,5,1,'',0,'56e9f9c497f8529fb7208d21ba480728',10,''),(7,'im009974','92ed2108c6f3171b0719d48da7ffe876','REVUELTAS RODRIGUEZ','JOSE','','','','','','','','','','','','jose.revueltas@imsdelgolfo.com.mx',0,0,'','','187.130.115.49','187-130-115-49.uninet-ide.com.mx',0,'2018-01-12 14:12:02',9,'2018-04-07 13:45:58','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,'',0,'74a4612c648f928f80f680bdd1bb8352',10,''),(8,'im013708','239b1676f29e2976995cdae3ff3c3601','PATERNO MATERO','NATO','','','','','','','','','','','','',0,0,'','','189.148.134.207','dsl-189-148-134-207-dyn.prod-infinitum.com.mx',1,'2018-01-12 14:12:24',1,'2018-03-28 13:10:00','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,1,'',0,'82c07d3b63a10eb5bf0d3022b2454d7a',10,''),(9,'im000003','82c2559140b95ccda9c6ca4a8b981f1e','REVUELTAS RODRIGUEZ','JOSE','','','','','','','','','','','','jose.revueltas@imsdelgolfo.com.mx',0,0,'','','187.130.115.49','187-130-115-49.uninet-ide.com.mx',2,'2018-01-19 19:01:48',2,'2018-04-07 10:39:31','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,'',0,'8e45632d844df6a852750f175b744269',10,''),(10,'im000017','e43e884c540de6138d8dd96b75cb6777','A ','TECNICO','','','','','','','','','','','','',0,0,'','','189.148.186.136','dsl-189-148-186-136-dyn.prod-infinitum.com.mx',2,'2018-03-23 19:08:08',2,'2018-03-23 19:08:23','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,3,1,'',0,'3cc4b873233fe13e369e5e6c527839d9',10,''),(11,'im000001','5eb767fd83d0bf6c2cd03ffdb4a89e70','AGUILAR MONTESINOS','RUBEN ARTURO','','','','','','','','','','','','ruben.aguilar@imsdelgolfo.com.mx',0,0,'','','187.154.150.15','dsl-187-154-150-15-dyn.prod-infinitum.com.mx',2,'2018-03-24 11:05:00',9,'2018-04-07 13:51:24','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,'',0,'3cce32f3ca9a79b1f35923c7acfd9139',10,''),(12,'im000018','621108c042023b099cd018eca9528620','DIAZ LOPEZ','CLAUDIO','','','','','','','','','','','','',0,0,'','','187.154.150.15','dsl-187-154-150-15-dyn.prod-infinitum.com.mx',2,'2018-03-24 11:15:04',9,'2018-04-07 13:50:16','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,3,1,'',0,'6c0fd4bc93083b733fdc149dae65de97',10,''),(13,'im000009','75d72000c9ba2eef34ddf1a68a86c747','BEAURREGARD OLAN ','LORENA','','','','','','','','','','','','lorenab@imsdelgolfo.com.mx',0,0,'','','187.130.115.49','187-130-115-49.uninet-ide.com.mx',2,'2018-03-24 12:08:28',9,'2018-04-07 13:49:50','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,1,'',0,'aafd119911bd4ac45b6a4926f029fef1',10,''),(14,'im000014','ac5671e1c55013e92ae8cd5142cd2d9b','OCAÑA ','CARLOS ','','','','','','','','','','','','',0,0,'','','189.148.134.207','dsl-189-148-134-207-dyn.prod-infinitum.com.mx',2,'2018-03-24 12:49:03',1,'2018-03-28 13:09:26','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,5,1,'',0,'1be33b29b52298d7ea57ce5781121551',10,''),(15,'im000011','0cddc1ec40958ca01955ac6f04297361','ULIN SASTRE','REMIGIO','','','','','','','','','','','','rulin@imsdelgolfo.com.mx',0,0,'','','187.154.150.15','dsl-187-154-150-15-dyn.prod-infinitum.com.mx',2,'2018-03-28 13:11:47',9,'2018-04-07 13:49:28','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,5,1,'',0,'6522136aa894b00d7eec1127f7a7ac32',10,''),(16,'im000008','ef4936f731d16f2914542eba993cbdae','SILVA LOPEZ','EFREN','','','','','','','','','','','','efren.silva@imsdelgolfo.com.mx',0,0,'','','187.130.115.49','187-130-115-49.uninet-ide.com.mx',2,'2018-03-28 13:12:00',9,'2018-04-07 13:48:59','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,3,1,'',0,'e1404fd3fdb79af9c6a6be507760be19',10,''),(17,'im000006','727183488db54891dcadd786fedd109c','VILLARREAL DE LA FLOR','ALICIA','','','','','','','','','','','','alicia.villarreal@imsdelgolfo.com.mx',0,0,'','','187.154.193.28','dsl-187-154-193-28-dyn.prod-infinitum.com.mx',2,'2018-03-28 13:12:05',9,'2018-04-07 13:48:38','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,4,1,'',0,'b311c54ca21e17714c33a9be9204f9d7',10,''),(18,'im000005','363fc646986ec3d31027dbd496dfd1db','GARCIA ARIAS','NATIVIDAD','','','','','','','','','','','','nato.garcia@imsdelgolfo.com.mx',0,0,'','','187.154.193.28','dsl-187-154-193-28-dyn.prod-infinitum.com.mx',2,'2018-03-28 13:24:49',9,'2018-04-07 13:48:17','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,1,'',0,'35a49fb6c127f77d8112c919657d941e',10,''),(19,'im000021','75926ed767980d66a748be994286afbb','prueba prueba','prueba','','','','','','','','','','','','',0,0,'','','','',2,'2018-04-06 17:30:25',0,'0000-00-00 00:00:00','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,5,1,'',0,'e39dfa5574a5b4a7d920f81e3be7c725',10,''),(20,'im000015','e24b04c127d9e50841a6672554cfcd88','SANTARELLI ','CARLOS','','','','','','','','','','','','',0,0,'','','','',2,'2018-04-06 18:07:07',0,'0000-00-00 00:00:00','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,5,1,'',0,'c452b5838891bc5c16af882d45bea516',10,''),(21,'im000023','3d77a7aced3ff32b6781172b409c0900','FLORES JIMENEZ','CARLOS ALBERTO','','','','','','','','','','','','carlos.flores@imsdelgolfo.com.mx',0,0,'','','187.154.193.28','dsl-187-154-193-28-dyn.prod-infinitum.com.mx',9,'2018-04-07 13:55:29',9,'2018-04-07 13:55:56','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,3,1,'',0,'2c94d88f87eb0634975c89ad35d873be',10,''),(22,'im000024','db23d9e8c2d8db1e427a1c44c585613d','PEREZ DOMINGUEZ','JUAN MANUEL','','','','','','','','','','','','jperez@imsdelgolfo.com.mx',0,0,'','','189.148.158.183','dsl-189-148-158-183-dyn.prod-infinitum.com.mx',9,'2018-04-07 14:01:24',1,'2018-04-07 16:33:15','',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,3,1,'',0,'9aed6de5847a1a65abb21ee305c47f1a',10,'');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`imsg`@`localhost`*/ /*!50003 TRIGGER `BEFORE_INSERTE_usuarios` BEFORE INSERT ON `usuarios` FOR EACH ROW Begin

	
	
    	set new.token_source = md5( concat( new.username,NOW() ) );
    
    

End */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`imsg`@`localhost`*/ /*!50003 TRIGGER `BEFORE_UPDATE_usuarios` BEFORE UPDATE ON `usuarios` FOR EACH ROW Begin

	if new.token_source = "" then
	
    	set new.token_source = md5( concat( new.username,now() ) );
    
    end if;

End */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`imsg`@`localhost`*/ /*!50003 TRIGGER `BEFORE_DELETE_usuarios` BEFORE DELETE ON `usuarios` FOR EACH ROW BEGIN

    SET @x = (
        SELECT iduser 
        FROM control_comentarios 
        WHERE iduser = old.iduser
    );

    IF @x > 0 THEN

	    DELETE 
        FROM `No se puede eliminar este usuario.` 
        WHERE x = -1;

	END IF;


END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `usuarios_conectados`
--

DROP TABLE IF EXISTS `usuarios_conectados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios_conectados` (
  `iduserconnect` int(10) NOT NULL AUTO_INCREMENT,
  `iduser` int(10) NOT NULL,
  `username` varchar(50) NOT NULL,
  `ultima_conexion` datetime NOT NULL,
  `isconectado` int(2) NOT NULL DEFAULT '0' COMMENT '0=No; 1=SI',
  `idemp` int(5) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL,
  `host` varchar(100) NOT NULL,
  `creado_por` int(10) NOT NULL DEFAULT '0',
  `creado_el` datetime NOT NULL,
  `modi_por` int(10) NOT NULL DEFAULT '0',
  `modi_el` datetime NOT NULL,
  PRIMARY KEY (`iduserconnect`),
  UNIQUE KEY `useremp` (`iduser`,`idemp`),
  KEY `iduseremp` (`iduser`,`idemp`,`isconectado`),
  KEY `useremp_ndx` (`username`,`idemp`,`isconectado`),
  KEY `unameemp` (`username`,`idemp`)
) ENGINE=MyISAM AUTO_INCREMENT=2404 DEFAULT CHARSET=utf8 COMMENT='Guarda los usuarios conectados';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios_conectados`
--

LOCK TABLES `usuarios_conectados` WRITE;
/*!40000 ALTER TABLE `usuarios_conectados` DISABLE KEYS */;
INSERT INTO `usuarios_conectados` (`iduserconnect`, `iduser`, `username`, `ultima_conexion`, `isconectado`, `idemp`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`) VALUES (2395,1,'devch','2018-04-07 16:34:48',1,1,'189.148.158.183','dsl-189-148-158-183-dyn.prod-infinitum.com.mx',1,'2017-06-27 15:26:50',1,'2018-04-07 16:34:48'),(2396,3,'im000001','2017-06-28 16:50:36',0,1,'189.129.7.167','dsl-189-129-7-167-dyn.prod-infinitum.com.mx',3,'2017-06-28 16:45:29',3,'2017-06-28 16:50:36'),(2397,6,'im000025','2017-06-28 18:01:13',0,1,'187.154.208.96','dsl-187-154-208-96-dyn.prod-infinitum.com.mx',6,'2017-06-28 17:58:02',6,'2017-06-28 18:01:13'),(2398,2,'dba','2018-04-07 10:32:14',1,1,'187.154.193.28','dsl-187-154-193-28-dyn.prod-infinitum.com.mx',2,'2017-07-04 16:01:44',2,'2018-04-07 10:32:14'),(2399,8,'im013708','2018-01-23 10:12:02',0,1,'187.154.150.103','dsl-187-154-150-103-dyn.prod-infinitum.com.mx',8,'2018-01-12 14:13:54',8,'2018-01-23 10:12:02'),(2400,11,'im000001','2018-03-24 11:06:29',0,1,'187.154.214.190','dsl-187-154-214-190-dyn.prod-infinitum.com.mx',11,'2018-03-24 11:05:23',11,'2018-03-24 11:06:29'),(2401,9,'im000003','2018-04-07 10:36:27',1,1,'187.154.150.15','dsl-187-154-150-15-dyn.prod-infinitum.com.mx',9,'2018-04-07 10:36:27',0,'0000-00-00 00:00:00'),(2402,22,'im000024','2018-04-07 16:34:44',0,1,'189.148.158.183','dsl-189-148-158-183-dyn.prod-infinitum.com.mx',22,'2018-04-07 14:03:36',22,'2018-04-07 16:34:44'),(2403,16,'im000008','2018-04-07 14:06:33',0,1,'187.130.115.49','187-130-115-49.uninet-ide.com.mx',16,'2018-04-07 14:05:56',16,'2018-04-07 14:06:33');
/*!40000 ALTER TABLE `usuarios_conectados` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`imsg`@`localhost`*/ /*!50003 TRIGGER `AFTER_INSERT_usuarios_conectados` AFTER INSERT ON `usuarios_conectados` FOR EACH ROW Begin

	INSERT INTO logs(iduser,date_mov,typemov,table_mov,idkey,fieldkey)
	VALUES(new.iduser,NOW(),'Init','Usuarios Conectados',new.iduser,'iduser') ; 

End */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`imsg`@`localhost`*/ /*!50003 TRIGGER `AFTER_UPDATE_usuarios_conectados` AFTER UPDATE ON `usuarios_conectados` FOR EACH ROW Begin

	if new.isconectado = 1 then
		set @conn = "Conectado";
	else
		set @conn = "Desconectado";
	end if;

	INSERT INTO logs(iduser,date_mov,typemov,table_mov,idkey,fieldkey)
	VALUES(new.iduser,NOW(),@conn,'Usuarios Conectados',new.iduser,'iduser') ; 


End */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `usuarios_niveldeacceso`
--

DROP TABLE IF EXISTS `usuarios_niveldeacceso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios_niveldeacceso` (
  `idusernivelacceso` int(10) NOT NULL AUTO_INCREMENT,
  `clave` int(5) NOT NULL,
  `nivel_de_acceso` varchar(50) NOT NULL,
  `movible` int(2) NOT NULL DEFAULT '0' COMMENT '0=No, 1=Si',
  `visible_in_com` int(2) NOT NULL DEFAULT '0',
  `tabla_filtrado` varchar(50) NOT NULL,
  `idemp` int(10) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `host` varchar(100) NOT NULL,
  `creado_por` int(10) NOT NULL,
  `creado_el` datetime NOT NULL,
  `modi_por` int(10) NOT NULL,
  `modi_el` datetime NOT NULL,
  PRIMARY KEY (`idusernivelacceso`),
  UNIQUE KEY `cveempnivacc` (`clave`,`idemp`),
  KEY `movible` (`movible`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='Catálogo de Nivel de Acceso de Usuarios';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios_niveldeacceso`
--

LOCK TABLES `usuarios_niveldeacceso` WRITE;
/*!40000 ALTER TABLE `usuarios_niveldeacceso` DISABLE KEYS */;
INSERT INTO `usuarios_niveldeacceso` (`idusernivelacceso`, `clave`, `nivel_de_acceso`, `movible`, `visible_in_com`, `tabla_filtrado`, `idemp`, `ip`, `host`, `creado_por`, `creado_el`, `modi_por`, `modi_el`) VALUES (1,1,'JEFE',0,0,'',1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(2,2,'SUPERVISOR',0,1,'',1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(3,3,'TECNICO',0,1,'_viDirectores',1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(4,4,'EJECUTIVA',0,0,'',1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00'),(5,5,'CONTACTO',0,0,'',1,'','',0,'0000-00-00 00:00:00',0,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `usuarios_niveldeacceso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'imsg_dbIMSG'
--
/*!50106 SET @save_time_zone= @@TIME_ZONE */ ;
/*!50106 DROP EVENT IF EXISTS `Close_All_Conections` */;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8mb4 */ ;;
/*!50003 SET character_set_results = utf8mb4 */ ;;
/*!50003 SET collation_connection  = utf8_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`imsg`@`localhost`*/ /*!50106 EVENT `Close_All_Conections` ON SCHEDULE EVERY 1 DAY STARTS '2017-06-29 00:01:00' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN

	UPDATE usuarios_conectados
    SET isconectado = 0
    WHERE 1;

END */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
DELIMITER ;
/*!50106 SET TIME_ZONE= @save_time_zone */ ;

--
-- Dumping routines for database 'imsg_dbIMSG'
--
/*!50003 DROP FUNCTION IF EXISTS `Generar_Usuario` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`imsg`@`localhost` FUNCTION `Generar_Usuario`(`pIdPer` INT) RETURNS int(10)
    NO SQL
Begin

	set @idusuario = 0;

	SELECT ap_paterno, ap_materno, nombre, email1, idemp, creado_por 
    INTO @app,@apm,@nombre,@email1,@idemp,@creado_por 
    FROM cat_personas 
    where idpersona = pIdPer;

		set @valDat1 = (Select concat('im',LPAD(pIdPer,6,'0')) );

		Insert into usuarios(username,password,apellidos,nombres,correoelectronico,idusernivelacceso,idemp,creado_por,creado_el)
    Values(@valDat1,md5(@valDat1),concat(@app,' ',@apm),@nombre,@email1,5,@idemp,@creado_por,NOW());
    
    	set @idusuario = (Select LAST_INSERT_ID() );
    
		Update cat_personas set idusuario = @idusuario where idpersona = pIdPer;


return @idusuario;

End ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `_viControlComentarios`
--

/*!50001 DROP VIEW IF EXISTS `_viControlComentarios`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`imsg`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `_viControlComentarios` AS select `cco`.`idcontrolcomentario` AS `idcontrolcomentario`,`cco`.`idcontrolmaster` AS `idcontrolmaster`,`cco`.`iduser` AS `iduser`,`per`.`nombre_persona` AS `nombre_persona`,`per`.`username` AS `username`,`cco`.`comentario` AS `comentario`,`cco`.`fecha` AS `fecha`,`cco`.`idemp` AS `idemp` from ((`control_comentarios` `cco` left join `_viControlMaster` `cma` on(((`cco`.`idcontrolmaster` = `cma`.`idcontrolmaster`) and (`cco`.`idemp` = `cma`.`idemp`)))) left join `_viPersonas` `per` on(((`cco`.`iduser` = `per`.`idusuario`) and (`cco`.`idemp` = `per`.`idemp`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `_viControlImporte`
--

/*!50001 DROP VIEW IF EXISTS `_viControlImporte`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`imsg`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `_viControlImporte` AS select `cim`.`idimporte` AS `idimporte`,`cim`.`idcontrolmaster` AS `idcontrolmaster`,`cim`.`cantidad` AS `cantidad`,`cim`.`idprecio` AS `idprecio`,`cim`.`codigo` AS `codigo`,`cim`.`precio_unitario` AS `precio_unitario`,`cim`.`importe` AS `importe`,`cim`.`observaciones` AS `observaciones`,`pre`.`clave_unidad` AS `clave_unidad`,`pre`.`unidad_medida` AS `unidad_medida`,`pre`.`clave_categoria` AS `clave_categoria`,`pre`.`precio_categoria` AS `precio_categoria`,`cim`.`status_importe` AS `status_importe` from (`control_importe` `cim` left join `_viPrecios` `pre` on(((`cim`.`idprecio` = `pre`.`idprecio`) and (`cim`.`idemp` = `pre`.`idemp`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `_viControlMaster`
--

/*!50001 DROP VIEW IF EXISTS `_viControlMaster`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`imsg`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `_viControlMaster` AS select `ord`.`idcontrolmaster` AS `idcontrolmaster`,`ord`.`idempresa` AS `idempresa`,`ord`.`idmodulo` AS `idmodulo`,`mar`.`marca` AS `marca`,`ord`.`idcliente` AS `idcliente`,`cli`.`reptte_legal` AS `reptte_legal`,`cli`.`empresa` AS `empresa`,`cli`.`tels_contacto` AS `tels_contacto`,`cli`.`cels_contacto` AS `cels_contacto`,`cli`.`emails_contacto` AS `emails_contacto`,`cli`.`direccion` AS `direccion`,`ord`.`idtecnico` AS `idtecnico`,`tec`.`tecnico` AS `tecnico`,`ord`.`idrecibio` AS `idrecibio`,`per`.`nombre_persona` AS `nombre_persona`,`ord`.`responsable` AS `responsable`,`ord`.`garantia` AS `garantia`,`ord`.`contrato` AS `contrato`,`ord`.`tipo` AS `tipo`,`ord`.`mantto` AS `mantto`,`ord`.`fentrada` AS `fentrada`,`ord`.`hora` AS `hora`,`ord`.`fsalida` AS `fsalida`,`ord`.`folgen` AS `folgen`,`ord`.`folmod` AS `folmod`,`ord`.`cargo` AS `cargo`,`ord`.`status` AS `status`,`col`.`descripcion` AS `descripcion`,`col`.`codigo_color_hex` AS `codigo_color_hex`,`ord`.`no_venta` AS `no_venta`,`ord`.`no_factura` AS `no_factura`,`ord`.`falla` AS `falla`,`ord`.`accesorios` AS `accesorios`,`ord`.`observaciones` AS `observaciones`,`ord`.`trabajo` AS `trabajo`,`ord`.`comment` AS `comment`,`ord`.`idclienterecibioentrega` AS `idclienterecibioentrega`,`per1`.`nombre_persona` AS `cliente_que_recibio`,`ord`.`idtecnicoentrego` AS `idtecnicoentrego`,`per2`.`nombre_persona` AS `tecnico_que_entrego`,`ord`.`status_master` AS `status_master`,`ord`.`idemp` AS `idemp`,`ord`.`creado_el` AS `creado_el`,`ord`.`modi_el` AS `modi_el` from (((((((`control_master` `ord` left join `cat_marcas` `mar` on(((`ord`.`idmodulo` = `mar`.`idmarca`) and (`ord`.`idemp` = `mar`.`idemp`)))) left join `_viEmpresaRepteLegal` `cli` on(((`ord`.`idcliente` = `cli`.`idrepresentantelegal`) and (`ord`.`idempresa` = `cli`.`idempresa`) and (`ord`.`idemp` = `cli`.`idemp`)))) left join `_viEmpresaTecnico` `tec` on(((`ord`.`idtecnico` = `tec`.`idtecnico`) and (`ord`.`idempresa` = `tec`.`idempresa`) and (`ord`.`idemp` = `tec`.`idemp`)))) left join `_viPersonas` `per` on(((`ord`.`idrecibio` = `per`.`idpersona`) and (`ord`.`idemp` = `per`.`idemp`)))) left join `cat_colores` `col` on(((`ord`.`status` = `col`.`idcolor`) and (`ord`.`idemp` = `col`.`idemp`)))) left join `_viPersonas` `per1` on(((`ord`.`idclienterecibioentrega` = `per1`.`idpersona`) and (`ord`.`idemp` = `per1`.`idemp`)))) left join `_viPersonas` `per2` on(((`ord`.`idtecnicoentrego` = `per2`.`idpersona`) and (`ord`.`idemp` = `per2`.`idemp`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `_viEmpresaRepteLegal`
--

/*!50001 DROP VIEW IF EXISTS `_viEmpresaRepteLegal`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`imsg`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `_viEmpresaRepteLegal` AS select `rem`.`idempresarepresentantelegal` AS `idempresarepresentantelegal`,`rem`.`idrepresentantelegal` AS `idrepresentantelegal`,`rem`.`idempresa` AS `idempresa`,`per`.`nombre_persona` AS `reptte_legal`,`per`.`tels_contacto` AS `tels_contacto`,`per`.`cels_contacto` AS `cels_contacto`,`per`.`emails_contacto` AS `emails_contacto`,`per`.`direccion` AS `direccion`,`emp`.`razon_social` AS `empresa`,`emp`.`emails` AS `emails_empresa`,`rem`.`status_empresa_reptte_legal` AS `status_empresa_reptte_legal`,`rem`.`idemp` AS `idemp` from ((`empresas_reptte_legal` `rem` left join `_viPersonas` `per` on(((`rem`.`idrepresentantelegal` = `per`.`idpersona`) and (`rem`.`idemp` = `per`.`idemp`)))) left join `_viEmpresas` `emp` on(((`rem`.`idempresa` = `emp`.`idempresa`) and (`rem`.`idemp` = `emp`.`idemp`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `_viEmpresaTecnico`
--

/*!50001 DROP VIEW IF EXISTS `_viEmpresaTecnico`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`imsg`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `_viEmpresaTecnico` AS select `ete`.`idempresatecnico` AS `idempresatecnico`,`ete`.`idtecnico` AS `idtecnico`,`ete`.`idempresa` AS `idempresa`,`emp`.`razon_social` AS `empresa`,`per`.`nombre_persona` AS `tecnico`,`ete`.`status_empresa_tecnico` AS `status_empresa_tecnico`,`ete`.`idemp` AS `idemp` from ((`empresas_tecnicos` `ete` left join `_viPersonas` `per` on(((`ete`.`idtecnico` = `per`.`idpersona`) and (`ete`.`idemp` = `per`.`idemp`)))) left join `_viEmpresas` `emp` on(((`ete`.`idempresa` = `emp`.`idempresa`) and (`ete`.`idemp` = `emp`.`idemp`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `_viEmpresas`
--

/*!50001 DROP VIEW IF EXISTS `_viEmpresas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`imsg`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `_viEmpresas` AS select `e`.`idempresa` AS `idempresa`,`e`.`rfc` AS `rfc`,`e`.`razon_social` AS `razon_social`,`e`.`calle` AS `calle`,`e`.`num_ext` AS `num_ext`,`e`.`num_int` AS `num_int`,`e`.`colonia` AS `colonia`,`e`.`localidad` AS `localidad`,`e`.`estado` AS `estado`,`e`.`pais` AS `pais`,`e`.`cp` AS `cp`,`e`.`emails` AS `emails`,`e`.`is_email` AS `is_email`,`e`.`status_empresa` AS `status_empresa`,`e`.`idemp` AS `idemp` from `cat_empresas` `e` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `_viMunicipios`
--

/*!50001 DROP VIEW IF EXISTS `_viMunicipios`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`imsg`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `_viMunicipios` AS select `m`.`idmunicipio` AS `idmunicipio`,`m`.`idestado` AS `idestado`,`e`.`clave` AS `clave_estado`,`e`.`estado` AS `estado`,`m`.`clave` AS `clave`,`m`.`municipio` AS `municipio`,`m`.`status_municipio` AS `status_municipio`,`m`.`idemp` AS `idemp` from (`cat_municipios` `m` left join `cat_estados` `e` on(((`m`.`idestado` = `e`.`idestado`) and (`m`.`idemp` = `e`.`idemp`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `_viPersonas`
--

/*!50001 DROP VIEW IF EXISTS `_viPersonas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`imsg`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `_viPersonas` AS select `per`.`idpersona` AS `idpersona`,`per`.`ap_paterno` AS `ap_paterno`,`per`.`ap_materno` AS `ap_materno`,`per`.`nombre` AS `nombre`,concat(ucase(trim(`per`.`ap_paterno`)),' ',ucase(trim(`per`.`ap_materno`)),' ',ucase(trim(`per`.`nombre`))) AS `nombre_persona`,`per`.`tel1` AS `tel1`,`per`.`tel2` AS `tel2`,concat(trim(`per`.`tel1`),', ',trim(`per`.`tel2`)) AS `tels_contacto`,`per`.`cel1` AS `cel1`,`per`.`cel2` AS `cel2`,concat(trim(`per`.`cel1`),', ',trim(`per`.`cel2`)) AS `cels_contacto`,`per`.`email1` AS `email1`,`per`.`email2` AS `email2`,concat(trim(`per`.`email1`),', ',trim(`per`.`email2`)) AS `emails_contacto`,`per`.`curp` AS `curp`,`per`.`rfc` AS `rfc`,`per`.`lugar_nacimiento` AS `lugar_nacimiento`,`per`.`fecha_nacimiento` AS `fecha_nacimiento`,date_format(`per`.`fecha_nacimiento`,'%d-%m-%Y') AS `cfecha_nacimiento`,`per`.`genero` AS `genero`,`per`.`ocupacion` AS `ocupacion`,`per`.`status_persona` AS `status_persona`,`per`.`domicilio_generico` AS `domicilio_generico`,`per`.`calle` AS `calle`,`per`.`num_ext` AS `num_ext`,`per`.`num_int` AS `num_int`,`per`.`colonia` AS `colonia`,`per`.`localidad` AS `localidad`,`per`.`estado` AS `estado`,`per`.`municipio` AS `municipio`,`per`.`pais` AS `pais`,`per`.`cp` AS `cp`,concat(trim(`per`.`calle`),' ',trim(`per`.`num_ext`),' ',trim(`per`.`num_int`),', ',trim(`per`.`colonia`),', ',trim(`per`.`localidad`),', ',trim(`per`.`municipio`)) AS `direccion`,`per`.`lugar_trabajo` AS `lugar_trabajo`,`per`.`idemp` AS `idemp`,`per`.`idusuario` AS `idusuario`,`u`.`username` AS `username`,`nau`.`clave` AS `clave`,`nau`.`idusernivelacceso` AS `idusernivelacceso` from ((`cat_personas` `per` left join `usuarios` `u` on(((`per`.`idusuario` = `u`.`iduser`) and (`per`.`idemp` = `u`.`idemp`)))) left join `usuarios_niveldeacceso` `nau` on(((`u`.`idusernivelacceso` = `nau`.`idusernivelacceso`) and (`u`.`idemp` = `nau`.`idemp`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `_viPrecios`
--

/*!50001 DROP VIEW IF EXISTS `_viPrecios`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`imsg`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `_viPrecios` AS select `pre`.`idprecio` AS `idprecio`,`pre`.`codigo` AS `codigo`,`pre`.`concepto` AS `concepto`,`pre`.`idunidadmedida` AS `idunidadmedida`,`med`.`clave` AS `clave_unidad`,`med`.`unidad_medida` AS `unidad_medida`,`pre`.`precio_unitario` AS `precio_unitario`,`pre`.`idpreciocategoria` AS `idpreciocategoria`,`cat`.`clave` AS `clave_categoria`,`cat`.`precio_categoria` AS `precio_categoria`,`pre`.`tipo` AS `tipo`,`pre`.`status_precio_unitario` AS `status_precio_unitario`,`pre`.`idemp` AS `idemp` from ((`cat_precios` `pre` left join `cat_unidades_medidas` `med` on(((`pre`.`idunidadmedida` = `med`.`idunidadmedida`) and (`pre`.`idemp` = `med`.`idemp`)))) left join `cat_precios_categorias` `cat` on(((`pre`.`idpreciocategoria` = `cat`.`idpreciocategoria`) and (`pre`.`idemp` = `cat`.`idemp`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `_viRegFis`
--

/*!50001 DROP VIEW IF EXISTS `_viRegFis`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`imsg`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `_viRegFis` AS select `rf`.`idregfis` AS `idregfis`,`rf`.`rfc` AS `rfc`,`rf`.`curp` AS `curp`,`rf`.`razon_social` AS `razon_social`,`rf`.`calle` AS `calle`,`rf`.`num_ext` AS `num_ext`,`rf`.`num_int` AS `num_int`,`rf`.`colonia` AS `colonia`,`rf`.`localidad` AS `localidad`,`rf`.`estado` AS `estado`,`rf`.`pais` AS `pais`,`rf`.`cp` AS `cp`,`rf`.`email1` AS `email1`,`rf`.`email2` AS `email2`,`rf`.`is_email` AS `is_email`,`rf`.`is_extranjero` AS `is_extranjero`,`rf`.`referencia` AS `referencia`,`rf`.`idfammig` AS `idfammig`,`rf`.`status_regfis` AS `status_regfis`,`rf`.`idemp` AS `idemp` from `cat_registros_fiscales` `rf` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `_viUsuarios`
--

/*!50001 DROP VIEW IF EXISTS `_viUsuarios`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`imsg`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `_viUsuarios` AS select `u`.`iduser` AS `iduser`,`u`.`username` AS `username`,`u`.`password` AS `password`,`u`.`apellidos` AS `apellidos`,`u`.`nombres` AS `nombres`,concat(`u`.`apellidos`,' ',`u`.`nombres`) AS `nombre_completo_usuario`,`u`.`foto` AS `foto`,`u`.`username` AS `user`,`u`.`registro` AS `registro`,`u`.`especialidad` AS `especialidad`,`u`.`domicilio` AS `domicilio`,`u`.`colonia` AS `colonia`,`u`.`idmunicipio` AS `idmunicipio`,`u`.`idestado` AS `idestado`,`u`.`teloficina` AS `teloficina`,`u`.`telpersonal` AS `telpersonal`,`u`.`telfax` AS `telfax`,`u`.`correoelectronico` AS `correoelectronico`,`edo`.`estado` AS `estado`,`mun`.`municipio` AS `municipio`,`u`.`idemp` AS `idemp`,`e`.`rs` AS `empresa`,`e`.`logo` AS `logoempresa`,`u`.`idusernivelacceso` AS `idusernivelacceso`,`un`.`nivel_de_acceso` AS `nivel_de_acceso`,(case when (`un`.`clave` is not null) then `un`.`clave` else 0 end) AS `clave`,`u`.`status_usuario` AS `status_usuario`,`u`.`token` AS `token`,`u`.`token_source` AS `token_source`,`u`.`token_validated` AS `token_validated`,`u`.`registrosporpagina` AS `registrosporpagina`,`u`.`param1` AS `param1` from ((((`usuarios` `u` left join `empresa` `e` on((`u`.`idemp` = `e`.`idemp`))) left join `cat_estados` `edo` on(((`u`.`idestado` = `edo`.`idestado`) and (`u`.`idemp` = `edo`.`idemp`)))) left join `cat_municipios` `mun` on(((`u`.`idmunicipio` = `mun`.`idmunicipio`) and (`u`.`idemp` = `mun`.`idemp`)))) left join `usuarios_niveldeacceso` `un` on(((`u`.`idusernivelacceso` = `un`.`idusernivelacceso`) and (`u`.`idemp` = `un`.`idemp`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `_viUsuariosConectados`
--

/*!50001 DROP VIEW IF EXISTS `_viUsuariosConectados`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`imsg`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `_viUsuariosConectados` AS select `uc`.`iduser` AS `iduser2`,`uc`.`isconectado` AS `isconectado`,`uc`.`ultima_conexion` AS `ultima_conexion`,`u`.`iduser` AS `iduser`,`u`.`username` AS `username`,`u`.`password` AS `password`,`u`.`apellidos` AS `apellidos`,`u`.`nombres` AS `nombres`,`u`.`nombre_completo_usuario` AS `nombre_completo_usuario`,`u`.`foto` AS `foto`,`u`.`user` AS `user`,`u`.`registro` AS `registro`,`u`.`especialidad` AS `especialidad`,`u`.`domicilio` AS `domicilio`,`u`.`colonia` AS `colonia`,`u`.`idmunicipio` AS `idmunicipio`,`u`.`idestado` AS `idestado`,`u`.`teloficina` AS `teloficina`,`u`.`telpersonal` AS `telpersonal`,`u`.`telfax` AS `telfax`,`u`.`correoelectronico` AS `correoelectronico`,`u`.`estado` AS `estado`,`u`.`municipio` AS `municipio`,`u`.`idemp` AS `idemp`,`u`.`empresa` AS `empresa`,`u`.`logoempresa` AS `logoempresa`,`u`.`idusernivelacceso` AS `idusernivelacceso`,`u`.`nivel_de_acceso` AS `nivel_de_acceso`,`u`.`clave` AS `clave`,`u`.`status_usuario` AS `status_usuario`,`u`.`token` AS `token`,`u`.`token_source` AS `token_source`,`u`.`token_validated` AS `token_validated`,`u`.`registrosporpagina` AS `registrosporpagina`,`u`.`param1` AS `param1` from (`usuarios_conectados` `uc` left join `_viUsuarios` `u` on(((`uc`.`iduser` = `u`.`iduser`) and (`uc`.`idemp` = `u`.`idemp`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-07 19:07:46
